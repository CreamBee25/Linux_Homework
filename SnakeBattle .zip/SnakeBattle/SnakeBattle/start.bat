@echo off
cls
echo.
echo   Snake Battle - Starting...
echo   ===========================
echo.

if not exist "%~dp0backend" (
    echo   [ERROR] Backend folder not found!
    echo   Please extract the entire ZIP file first.
    pause
    exit /b 1
)

cd /d "%~dp0backend"

echo   [1/3] Checking Python...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo   [ERROR] Python not installed!
    echo   Install Python 3.10+ from https://www.python.org/downloads/
    echo   Make sure to check "Add Python to PATH"
    pause
    exit /b 1
)
python --version
echo   OK
echo.

echo   [2/3] Installing dependencies...
echo   (may take 1-2 minutes)
echo.
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
if %errorlevel% neq 0 (
    echo   [WARN] Mirror failed, trying default...
    pip install -r requirements.txt
    if %errorlevel% neq 0 (
        echo   [ERROR] Install failed. Check your internet.
        pause
        exit /b 1
    )
)
echo   OK
echo.

:: Try to open firewall (needs admin, silent if fails)
netsh advfirewall firewall add rule name="SnakeBattle" dir=in action=allow protocol=TCP localport=8000 >nul 2>&1

echo   [3/3] Starting game...
echo.
python launcher.py

echo.
echo   Game stopped.
pause
