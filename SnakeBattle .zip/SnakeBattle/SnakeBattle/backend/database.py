"""数据库连接配置"""

import os

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+asyncpg://snake:snake123@localhost:5432/snake_battle",
)

# 同步 URL（用于 SQLite 回退）
SYNC_DATABASE_URL = os.getenv(
    "SYNC_DATABASE_URL",
    "sqlite+aiosqlite:///./snake_battle.db",
)

# 尝试使用 PostgreSQL，失败则回退 SQLite
USE_POSTGRES = os.getenv("USE_POSTGRES", "false").lower() == "true"

if USE_POSTGRES:
    engine = create_async_engine(DATABASE_URL, echo=False)
else:
    # SQLite 回退
    engine = create_async_engine(SYNC_DATABASE_URL, echo=False)

async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


async def get_db() -> AsyncSession:
    """获取数据库会话"""
    async with async_session() as session:
        yield session


async def init_db():
    """初始化数据库表"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
