"""SQLAlchemy 数据模型"""

import uuid
from datetime import datetime

from sqlalchemy import Column, DateTime, Float, Integer, String, Text
from sqlalchemy.dialects.postgresql import UUID

from database import Base


def gen_uuid():
    return str(uuid.uuid4())


class Player(Base):
    """玩家表"""
    __tablename__ = "players"

    id = Column(String(36), primary_key=True, default=gen_uuid)
    username = Column(String(50), unique=True, nullable=False, index=True)
    password_hash = Column(String(128), nullable=False, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

    total_games = Column(Integer, default=0)
    total_score = Column(Integer, default=0)
    high_score = Column(Integer, default=0)
    max_length = Column(Integer, default=0)
    total_kills = Column(Integer, default=0)


class GameSession(Base):
    """游戏对局表"""
    __tablename__ = "game_sessions"

    id = Column(String(36), primary_key=True, default=gen_uuid)
    started_at = Column(DateTime, default=datetime.utcnow)
    ended_at = Column(DateTime, nullable=True)
    player_count = Column(Integer, default=0)
    ai_count = Column(Integer, default=0)
    duration_seconds = Column(Integer, default=0)


class PlayerScore(Base):
    """玩家战绩表"""
    __tablename__ = "player_scores"

    id = Column(String(36), primary_key=True, default=gen_uuid)
    player_id = Column(String(36), nullable=False, index=True)
    session_id = Column(String(36), nullable=False)
    username = Column(String(50), nullable=False)
    score = Column(Integer, default=0)
    max_length = Column(Integer, default=0)
    kills = Column(Integer, default=0)
    rank = Column(Integer, default=0)
    snake_color = Column(String(10), default="#FF4444")
    created_at = Column(DateTime, default=datetime.utcnow)


class LeaderboardEntry(Base):
    """排行榜（按模式独立，每模式存Top10）"""
    __tablename__ = "leaderboard"

    id = Column(Integer, primary_key=True, autoincrement=True)
    mode = Column(String(20), nullable=False, index=True)  # endless/timed/score
    username = Column(String(50), nullable=False)
    score = Column(Integer, default=0)
    updated_at = Column(DateTime, default=datetime.utcnow)
