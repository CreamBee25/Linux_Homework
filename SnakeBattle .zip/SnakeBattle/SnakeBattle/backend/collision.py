"""碰撞检测"""

import math

from config import SNAKE_SEGMENT_RADIUS, SNAKE_SELF_COLLISION_DELAY


def check_collision(snake, other_snakes: list, world_w: float, world_h: float) -> str | None:
    """
    检测蛇头是否碰撞。返回碰撞类型: "boundary" | "self" | "other" | "head_on" | None
    """
    if not snake.alive:
        return None

    hx, hy = snake.head
    head_r = snake.radius * 0.85  # 碰撞半径略小于视觉半径

    # 1. 边界碰撞
    if (hx - head_r < 0 or hx + head_r > world_w
            or hy - head_r < 0 or hy + head_r > world_h):
        return "boundary"

    # 2. 自己身体碰撞（跳过前N段，阈值随长度自适应）
    self_threshold = head_r * 0.6  # 自身碰撞更宽容
    for i, seg in enumerate(snake.segments):
        if i < SNAKE_SELF_COLLISION_DELAY:
            continue
        sx, sy = seg
        if math.hypot(hx - sx, hy - sy) < self_threshold:
            return "self"

    # 3. 其他蛇碰撞
    for other in other_snakes:
        if other is snake or not other.alive:
            continue

        ohx, ohy = other.head
        other_r = other.radius * 0.85

        # 3a. 头对头碰撞
        if math.hypot(hx - ohx, hy - ohy) < head_r + other_r:
            return "head_on"

        # 3b. 头撞其他蛇身体
        for j, seg in enumerate(other.segments):
            if j < 3:  # 跳过对方蛇头附近3段
                continue
            sx, sy = seg
            if math.hypot(hx - sx, hy - sy) < head_r * 0.8:
                return "other"

    return None


def check_food_collision(snake, food_manager) -> list:
    """检查蛇头附近可吃的食物"""
    hx, hy = snake.head
    eat_radius = snake.radius + 15
    return food_manager.remove_near(hx, hy, eat_radius)
