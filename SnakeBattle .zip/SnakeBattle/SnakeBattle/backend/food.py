"""食物系统"""

import math
import random
from dataclasses import dataclass, field

from config import (
    WORLD_WIDTH, WORLD_HEIGHT, FOOD_COUNT, FOOD_MIN_RADIUS,
    FOOD_MAX_RADIUS, FOOD_SPAWN_RATE, FOOD_DEATH_DROP_MIN,
    FOOD_DEATH_DROP_MAX, BORDER_WIDTH,
)

# 食物生命周期（tick数）：自然生成永不过期，死亡掉落60秒后消失
FOOD_DROP_LIFETIME = 20 * 60  # 60秒 × 20tick


@dataclass
class Food:
    """食物/光点"""
    x: float
    y: float
    radius: float
    color: str = "#FFFF44"
    lifetime: int = -1  # -1 = 永不过期，>0 = 剩余tick数

    def to_dict(self) -> dict:
        return {
            "x": self.x,
            "y": self.y,
            "r": self.radius,
            "c": self.color,
        }


class FoodManager:
    """食物管理器"""

    def __init__(self):
        self.foods: list[Food] = []
        self._spawn_timer = 0.0
        self._init_foods()

    def _random_color(self) -> str:
        colors = [
            "#FFFF44", "#FF66AA", "#44FF44", "#FF44FF",
            "#44FFFF", "#FF4488", "#88FF44", "#FFCC00",
            "#FF5555", "#4488FF", "#AAFF44", "#44FFAA",
        ]
        return random.choice(colors)

    def _random_position(self) -> tuple:
        margin = BORDER_WIDTH + 50
        x = random.uniform(margin, WORLD_WIDTH - margin)
        y = random.uniform(margin, WORLD_HEIGHT - margin)
        return x, y

    def _random_radius(self) -> float:
        return random.uniform(FOOD_MIN_RADIUS, FOOD_MAX_RADIUS)

    def _init_foods(self):
        for _ in range(FOOD_COUNT):
            x, y = self._random_position()
            self.foods.append(Food(
                x=x, y=y,
                radius=self._random_radius(),
                color=self._random_color(),
                lifetime=-1,  # 初始食物永不过期
            ))

    def spawn_from_snake(self, segments: list, color: str):
        """蛇死亡后掉落大球（总量 = 生前长度的30%，体型匹配）"""
        total_len = len(segments)
        drop_value = max(3, int(total_len * 0.3))  # 总掉落值
        ball_count = max(2, drop_value // 3)       # 每球≈3段，至少2球
        ball_radius = 4 + total_len * 0.25         # 体型匹配：长蛇掉大球

        # 在蛇身体范围内随机散落
        for _ in range(ball_count):
            seg = random.choice(segments)
            ox = random.uniform(-25, 25)
            oy = random.uniform(-25, 25)
            self.foods.append(Food(
                x=seg[0] + ox,
                y=seg[1] + oy,
                radius=min(ball_radius, 25),  # 最大半径25
                color=color,
                lifetime=FOOD_DROP_LIFETIME,
            ))

    def update(self):
        """更新食物（生成 + 过期清理 + 超量清理）"""
        # 1. 过期清理
        self.foods = [f for f in self.foods if f.lifetime == -1 or f.lifetime > 0]
        for f in self.foods:
            if f.lifetime > 0:
                f.lifetime -= 1

        # 2. 超量时删除最旧的食物（优先删有过期时间的）
        max_foods = FOOD_COUNT * 3
        if len(self.foods) > max_foods:
            # 分开有过期和无过期的
            timed = [f for f in self.foods if f.lifetime > 0]
            permanent = [f for f in self.foods if f.lifetime == -1]
            # 优先保留无过期食物 + 按过期时间排序保留
            if len(timed) > max_foods - len(permanent):
                timed.sort(key=lambda f: f.lifetime)
                timed = timed[-(max_foods - len(permanent)):]
            self.foods = permanent + timed
            self._spawn_timer = 0

        # 3. 自然生成
        if len(self.foods) < max_foods:
            self._spawn_timer += 1.0 / 20
            spawn_count = int(self._spawn_timer * FOOD_SPAWN_RATE)
            if spawn_count > 0:
                self._spawn_timer -= spawn_count / FOOD_SPAWN_RATE
                for _ in range(spawn_count):
                    if len(self.foods) >= max_foods:
                        break
                    x, y = self._random_position()
                    self.foods.append(Food(
                        x=x, y=y,
                        radius=self._random_radius(),
                        color=self._random_color(),
                        lifetime=-1,
                    ))

    def remove_near(self, x: float, y: float, radius: float) -> list[Food]:
        """移除范围内的食物，返回被吃掉的食物列表"""
        eaten = []
        remaining = []
        for f in self.foods:
            dist = math.hypot(f.x - x, f.y - y)
            if dist < radius + f.radius:
                eaten.append(f)
            else:
                remaining.append(f)
        self.foods = remaining
        return eaten

    def get_in_view(self, x: float, y: float, view_w: float, view_h: float) -> list[Food]:
        """获取视野内的食物"""
        half_w = view_w / 2
        half_h = view_h / 2
        return [
            f for f in self.foods
            if x - half_w - 50 < f.x < x + half_w + 50
            and y - half_h - 50 < f.y < y + half_h + 50
        ]
