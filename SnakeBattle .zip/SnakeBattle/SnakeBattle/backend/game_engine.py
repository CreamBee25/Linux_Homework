"""核心游戏引擎 — 权威服务端游戏循环"""

import asyncio
import math
import time
import uuid

from ai_bot import AIBot
from collision import check_collision, check_food_collision
from config import (
    AI_COUNT, AI_NAMES, AI_RESPAWN_DELAY, BROADCAST_RATE,
    FOOD_COUNT, LEADERBOARD_INTERVAL, MAX_GAME_TIME,
    SNAKE_COLORS, TICK_RATE, VIEWPORT_MARGIN,
    WORLD_HEIGHT, WORLD_WIDTH,
)
from food import FoodManager
from leaderboard_storage import get_leaderboard, update_leaderboard
from snake import Snake


class GameEngine:
    """游戏引擎单例"""

    def __init__(self, room_code: str = ""):
        self.room_code = room_code
        self.snakes: dict[str, Snake] = {}  # {snake_id: Snake}
        self.food_manager = FoodManager()
        self.ai_bot = AIBot()
        self.tick = 0
        self.running = False
        self._task: asyncio.Task | None = None

        # WebSocket 连接映射 {snake_id: websocket}
        self.connections: dict[str, any] = {}

        # 广播队列
        self._broadcast_queue: list = []

        # 颜色分配
        self._color_index = 0
        self._ai_name_index = 0

        # 游戏模式
        self.game_mode = "endless"  # endless | timed | score
        self.mode_config = 0        # timed=秒数, score=目标分数
        self.game_over = False
        self.winner = None
        self.game_start_time = 0.0
        self.mode_end_time = 0.0
        self._mode_timer_started = False  # 有真人加入才开始计时

        # 排行榜由数据库管理（leaderboard_storage）

        # 游戏开始时间
        self.start_time = time.time()

    def _next_color(self) -> str:
        color = SNAKE_COLORS[self._color_index % len(SNAKE_COLORS)]
        self._color_index += 1
        return color

    def _next_ai_name(self) -> str:
        name = AI_NAMES[self._ai_name_index % len(AI_NAMES)]
        self._ai_name_index += 1
        return name

    # ==================== 玩家管理 ====================

    def add_player(self, snake_id: str, username: str, is_ai: bool = False) -> Snake:
        """添加玩家"""
        color = self._next_color()
        name = username if not is_ai else self._next_ai_name()
        snake = Snake(
            id=snake_id,
            username=name,
            color=color,
            is_ai=is_ai,
        )
        self.snakes[snake_id] = snake

        # 第一个真人加入 → 开始倒计时
        if not is_ai and not self._mode_timer_started:
            self._start_mode_timer()

        return snake

    def _start_mode_timer(self):
        """启动模式计时器（限时/得分模式）"""
        if self.game_mode == "endless":
            return
        self._mode_timer_started = True
        self.game_start_time = time.time()
        if self.game_mode == "timed":
            self.mode_end_time = self.game_start_time + self.mode_config
        elif self.game_mode == "score":
            self.mode_end_time = self.game_start_time + MAX_GAME_TIME
        print(f"[GAME] 房间 {self.room_code} 模式计时开始 "
              f"(mode={self.game_mode}, config={self.mode_config})")

    def remove_player(self, snake_id: str):
        """移除玩家"""
        if snake_id in self.snakes:
            self.snakes[snake_id].alive = False
        self.connections.pop(snake_id, None)
        if snake_id in self.snakes:
            del self.snakes[snake_id]

    def set_mode(self, mode: str, config: int):
        """设置游戏模式（不启动计时，等真人加入时启动）"""
        if self.game_mode == mode and self.mode_config == config and not self.game_over:
            return
        self.game_mode = mode
        self.mode_config = config
        self.game_over = False
        self.winner = None
        self._mode_timer_started = False  # 等真人加入才计时

        # 重置所有AI到初始大小
        for s in self.snakes.values():
            if s.is_ai:
                s.respawn()

    # ==================== 游戏循环 ====================

    async def start(self):
        """启动游戏循环"""
        if self.running:
            return

        # 初始化 AI
        for i in range(AI_COUNT):
            ai_id = f"ai_{i}"
            self.add_player(ai_id, "", is_ai=True)

        self.running = True
        self._task = asyncio.create_task(self._game_loop())

    async def stop(self):
        """停止游戏循环"""
        self.running = False
        if self._task:
            self._task.cancel()
        self.snakes.clear()
        self.connections.clear()

    async def _game_loop(self):
        """主游戏循环"""
        tick_duration = 1.0 / TICK_RATE
        last_leaderboard = time.time()

        while self.running:
            try:
                loop_start = time.time()

                # 游戏结束后冻结一切
                if self.game_over:
                    await asyncio.sleep(0.5)
                    continue

                # 1. 更新 AI
                await self._update_ai_async()

                # 2. 移动所有蛇
                for snake in list(self.snakes.values()):
                    snake.update()
                await asyncio.sleep(0)

                # 3. 碰撞检测
                self._check_collisions()

                # 4. 吃食物
                self._eat_food()

                # 5. 更新食物
                self.food_manager.update()

                # 6. 重生（无尽模式仅AI，限时/得分模式全自动复活）
                if self.game_mode == "endless":
                    self._respawn_ai()
                else:
                    self._auto_respawn_dead()

                # 7. 广播状态
                if self.tick % max(1, TICK_RATE // BROADCAST_RATE) == 0:
                    await self._broadcast_state()

                # 8. 胜利条件
                if not self.game_over:
                    self._check_win_condition()

                # 9. 排行榜
                now = time.time()
                if now - last_leaderboard >= LEADERBOARD_INTERVAL:
                    await self._broadcast_leaderboard()
                    last_leaderboard = now

                self.tick += 1

                # 控制 tick 频率
                elapsed = time.time() - loop_start
                sleep_time = tick_duration - elapsed
                if sleep_time > 0:
                    await asyncio.sleep(sleep_time)
            except Exception as e:
                import traceback
                print(f"[GAME LOOP] 崩溃: {type(e).__name__}: {e}")
                traceback.print_exc()
                await asyncio.sleep(1)  # 崩溃后等1秒再重试

    def _update_ai(self):
        """更新 AI 决策"""
        all_snakes = list(self.snakes.values())
        foods = self.food_manager.foods

        for snake in all_snakes:
            if not snake.is_ai or not snake.alive:
                continue
            target_x, target_y, boost = self.ai_bot.decide(snake, all_snakes, foods)
            snake.set_target(target_x, target_y)
            snake.boosting = boost

    async def _update_ai_async(self):
        """更新 AI 决策（async，每蛇间 yield）"""
        all_snakes = list(self.snakes.values())
        foods = self.food_manager.foods
        for i, snake in enumerate(all_snakes):
            if not snake.is_ai or not snake.alive:
                continue
            target_x, target_y, boost = self.ai_bot.decide(snake, all_snakes, foods)
            snake.set_target(target_x, target_y)
            snake.boosting = boost
            if i % 2 == 1:
                await asyncio.sleep(0)

    def _check_collisions(self):
        """碰撞检测与处理"""
        all_snakes = list(self.snakes.values())

        for snake in all_snakes:
            if not snake.alive:
                continue

            collision = check_collision(snake, all_snakes, WORLD_WIDTH, WORLD_HEIGHT)

            if collision is None:
                continue

            # 蛇死亡，掉落食物
            self.food_manager.spawn_from_snake(snake.segments, snake.color)
            snake.die()

            # 记录击杀
            if collision == "head_on":
                # 头对头：找到对方蛇
                for other in all_snakes:
                    if other is snake or not other.alive:
                        continue
                    d = math.hypot(snake.x - other.x, snake.y - other.y)
                    if d < snake.radius + other.radius:
                        # 双方都死
                        self.food_manager.spawn_from_snake(other.segments, other.color)
                        other.die()

    def _eat_food(self):
        """蛇吃食物"""
        for snake in self.snakes.values():
            if not snake.alive:
                continue
            eaten = check_food_collision(snake, self.food_manager)
            if eaten:
                total_growth = sum(f.radius / 4 for f in eaten)
                snake.grow(total_growth)

    def _respawn_ai(self):
        """AI 重生"""
        for snake in self.snakes.values():
            if snake.is_ai and snake.can_respawn():
                snake.respawn()

    # ==================== 广播 ====================

    async def _broadcast_state(self):
        """广播游戏状态给所有玩家"""
        all_snakes = list(self.snakes.values())

        for snake_id, ws in list(self.connections.items()):
            try:
                player_snake = self.snakes.get(snake_id)
                if player_snake is None:
                    continue

                state = self._build_state_for_player(player_snake, all_snakes)
                await ws.send_json(state)
            except Exception as e:
                import traceback
                print(f"[BROADCAST] 发送给 {snake_id} 失败: {type(e).__name__}: {e}")
                traceback.print_exc()
                self.connections.pop(snake_id, None)

    def _build_state_for_player(self, player: Snake, all_snakes: list) -> dict:
        """构建某个玩家视角的游戏状态"""
        px, py = player.head

        # 发送所有存活蛇
        visible_snakes = [s.to_dict() for s in all_snakes if s.alive]

        # 食物（视野裁剪以减少数据量）
        view_w, view_h = 2000, 1500
        visible_food = self.food_manager.get_in_view(px, py, view_w, view_h)
        food_data = [f.to_dict() for f in visible_food]

        # 所有存活蛇的分数（用于排行榜）
        scores = sorted(
            [
                {"username": s.username, "score": s.score, "length": int(s.length),
                 "alive": s.alive, "color": s.color}
                for s in all_snakes
            ],
            key=lambda x: x["score"], reverse=True
        )[:10]

        # 模式信息
        mode_info = {"mode": self.game_mode}
        if not self._mode_timer_started:
            mode_info["waiting"] = True  # 等待玩家加入
        elif self.game_mode == "timed":
            mode_info["time_left"] = max(0, int(self.mode_end_time - time.time()))
            mode_info["time_total"] = self.mode_config
        elif self.game_mode == "score":
            mode_info["target"] = self.mode_config
            mode_info["time_left"] = max(0, int(self.mode_end_time - time.time()))

        return {
            "type": "game_state",
            "tick": self.tick,
            "snakes": visible_snakes,
            "foods": food_data,
            "scores": scores,
            "player": player.to_dict() if player.alive else None,
            "dead": not player.alive,
            "game_over": self.game_over,
            "winner": self.winner.username if self.winner else None,
            "mode_info": mode_info,
        }

    async def _broadcast_leaderboard(self):
        """广播排行榜"""
        all_snakes = list(self.snakes.values())
        scores = sorted(
            [
                {"username": s.username, "score": s.score, "length": int(s.length),
                 "alive": s.alive, "color": s.color}
                for s in all_snakes
                if s.alive or s.score > 0
            ],
            key=lambda x: x["score"], reverse=True
        )[:10]

        msg = {"type": "leaderboard", "scores": scores}

        for ws in list(self.connections.values()):
            try:
                await ws.send_json(msg)
            except Exception:
                pass

    # ==================== 玩家操作 ====================

    def handle_input(self, snake_id: str, target_x: float, target_y: float, boost: bool, sensitivity: float = 1.0):
        """处理玩家输入"""
        snake = self.snakes.get(snake_id)
        if snake is None or not snake.alive:
            return
        snake.set_target(target_x, target_y)
        snake.boosting = boost
        snake.sensitivity = max(0.3, min(3.0, sensitivity))  # 限制范围

    def handle_restart(self, snake_id: str):
        """玩家重新开始"""
        snake = self.snakes.get(snake_id)
        if snake is None:
            return
        if not snake.alive:
            snake.respawn()

    # ==================== 胜利条件 ====================

    def _check_win_condition(self):
        """检查限时/得分模式的胜利条件（计时未启动则跳过）"""
        if self.game_mode == "endless" or not self._mode_timer_started:
            return

        now = time.time()
        all_snakes = list(self.snakes.values())

        if self.game_mode == "timed":
            if now >= self.mode_end_time:
                self.game_over = True
                # 最长玩家获胜
                alive = [s for s in all_snakes if s.alive]
                if alive:
                    self.winner = max(alive, key=lambda s: s.length)
                else:
                    scored = [s for s in all_snakes if s.score > 0]
                    self.winner = max(scored, key=lambda s: s.score) if scored else None
                asyncio.create_task(self._broadcast_game_over())

        elif self.game_mode == "score":
            # 有人达到目标分
            for s in all_snakes:
                if s.alive and s.score >= self.mode_config:
                    self.game_over = True
                    self.winner = s
                    asyncio.create_task(self._broadcast_game_over())
                    return
            # 超时结算
            if now >= self.mode_end_time:
                self.game_over = True
                alive = [s for s in all_snakes if s.alive]
                self.winner = max(alive, key=lambda s: s.score) if alive else None
                asyncio.create_task(self._broadcast_game_over())

    async def _broadcast_game_over(self):
        """广播游戏结束（含数据库排行榜）"""
        # 将当前玩家写入数据库排行榜
        players = [
            {"username": s.username, "score": s.score}
            for s in self.snakes.values() if s.score > 0 or s.alive
        ]
        await update_leaderboard(self.game_mode, players)

        # 从数据库读取最新排行榜
        lb = await get_leaderboard(self.game_mode)

        msg = {
            "type": "game_over",
            "winner": self.winner.username if self.winner else "无",
            "winner_score": self.winner.score if self.winner else 0,
            "winner_length": int(self.winner.length) if self.winner else 0,
            "mode": self.game_mode,
            "leaderboard": lb,
        }
        for ws in list(self.connections.values()):
            try:
                await ws.send_json(msg)
            except Exception:
                pass

    def _auto_respawn_dead(self):
        """限时/得分模式：自动复活，长度不超过场上最长的80%"""
        alive = [s for s in self.snakes.values() if s.alive]
        max_len = max((s.length for s in alive), default=20)
        cap = max(15, int(max_len * 0.8))

        for snake in list(self.snakes.values()):
            if not snake.alive and snake.death_timer <= 0:
                snake.respawn(cap_length=cap)


# 注意：不再使用全局单例，每个房间有独立的 GameEngine 实例
# 通过 room_manager 获取房间对应的 engine
