"""游戏配置参数"""

# ========== 世界参数 ==========
WORLD_WIDTH = 4000
WORLD_HEIGHT = 4000
BORDER_WIDTH = 50  # 红色边界宽度（视觉）

# ========== 蛇参数 ==========
SNAKE_BASE_SPEED = 7.0  # 基础速度 (px/tick) → 140px/s
SNAKE_BOOST_SPEED = 12.0  # 加速速度 (px/tick) → 240px/s
SNAKE_SEGMENT_RADIUS = 8  # 段半径 (px)
SNAKE_MIN_LENGTH = 10  # 最小长度（段数）
SNAKE_START_LENGTH = 15  # 初始长度
SNAKE_TURN_SPEED = 0.18  # 每 tick 最大转角 (弧度) — 提高灵敏度
SNAKE_TURN_SPEED_MIN = 0.06  # 最小转角 (弧度) — 微调时不僵硬
SNAKE_SEGMENT_SPACING = 8  # 段间距 (px) — 随长度增加
SNAKE_BOOST_COST = 0.3  # 加速消耗（段/tick）— 降低损耗
SNAKE_MAX_GROWTH_PER_TICK = 3  # 每tick最多增长段数，防止尾巴补段穿模
SNAKE_SELF_COLLISION_DELAY = 12  # 前N段不会撞到自己

# ========== 食物参数 ==========
FOOD_COUNT = 800  # 常驻食物数量
FOOD_MIN_RADIUS = 3  # 最小食物半径
FOOD_MAX_RADIUS = 8  # 最大食物半径
FOOD_SPAWN_RATE = 8  # 每秒补充的食物数
FOOD_DEATH_DROP_MIN = 1  # 死亡每段最少掉落
FOOD_DEATH_DROP_MAX = 3  # 死亡每段最多掉落

# ========== 游戏循环 ==========
TICK_RATE = 20  # 服务器 tick/秒
BROADCAST_RATE = 20  # 广播频率 (tick/秒)
LEADERBOARD_INTERVAL = 1.0  # 排行榜广播间隔（秒）

# ========== AI 参数 ==========
AI_COUNT = 8  # AI 蛇数量

# ========== 游戏模式 ==========
TIMED_OPTIONS = [90, 120, 150, 180, 300, 600]  # 限时模式可选秒数
SCORE_OPTIONS = [1000, 2000, 3000, 5000, 7500, 10000]  # 得分模式可选目标
MAX_GAME_TIME = 900  # 得分模式最长15分钟
AI_RESPAWN_DELAY = 3.0  # AI 死亡后重生延迟（秒）
AI_VISION_RANGE = 300  # AI 视野范围 (px)
AI_NAMES = [
    "小蛇悠悠", "闪电侠", "贪吃王者", "萌新小绿",
    "暗影刺客", "彩虹糖", "暴风赤红", "深海巨蟒",
    "银色旋风", "金色传说", "毒液", "星辰大海",
    "疾风剑豪", "无畏先锋", "暗夜猎手", "冰晶凤凰",
    "熔岩巨兽", "雷霆之子", "虚空行者", "幻影刺客",
]

# ========== 颜色预设 ==========
SNAKE_COLORS = [
    "#FF5555", "#44DD44", "#4488FF", "#EE44EE",
    "#44DDFF", "#FF66BB", "#66FF66", "#DDDD44",
    "#8866FF", "#FF88CC", "#44FFAA", "#FF6688",
    "#66AAFF", "#AAFF44", "#FF44AA", "#44FFDD",
]

# ========== 视野裁剪 ==========
VIEWPORT_MARGIN = 200  # 视野外扩展边距 (px)
