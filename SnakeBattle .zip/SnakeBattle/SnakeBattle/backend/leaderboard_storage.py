"""排行榜数据库操作"""

import random

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from database import async_session
from models import LeaderboardEntry

FAKE_NAMES = [
    "蛇王King", "闪电侠", "终极猎手", "彩虹糖", "暗影刺客",
    "暴风赤红", "深海巨蟒", "金色传说", "毒液Venom", "冰晶凤凰",
    "幻影刺客", "星辰大海", "疾风剑豪", "无畏先锋", "暗夜猎手",
]


async def init_leaderboard():
    """首次启动时给空榜填假数据"""
    async with async_session() as db:
        for mode in ["endless", "timed", "score"]:
            count = (await db.execute(
                select(LeaderboardEntry).where(LeaderboardEntry.mode == mode)
            )).scalars().all()
            if len(count) >= 10:
                continue  # 已满

            # 需要补到10条
            need = 10 - len(count)
            for i in range(need):
                name = FAKE_NAMES[(len(count) + i) % len(FAKE_NAMES)]
                score = random.randint(200, 1500) * (i + 1) // 2
                db.add(LeaderboardEntry(mode=mode, username=name, score=score))
            await db.commit()


async def get_leaderboard(mode: str) -> list[dict]:
    """获取某模式排行榜 Top 10"""
    async with async_session() as db:
        rows = (await db.execute(
            select(LeaderboardEntry)
            .where(LeaderboardEntry.mode == mode)
            .order_by(LeaderboardEntry.score.desc())
            .limit(10)
        )).scalars().all()
        return [{"username": r.username, "score": r.score} for r in rows]


async def update_leaderboard(mode: str, players: list):
    """用当前玩家分数更新排行榜（同名取最高分，取Top10）"""
    async with async_session() as db:
        # 读取现有记录
        existing = (await db.execute(
            select(LeaderboardEntry).where(LeaderboardEntry.mode == mode)
        )).scalars().all()

        # 合并：{username: max_score}
        merged = {}
        for e in existing:
            merged[e.username] = max(merged.get(e.username, 0), e.score)
        for p in players:
            name = p["username"]
            score = p["score"]
            merged[name] = max(merged.get(name, 0), score)

        # 排序取Top10
        top10 = sorted(merged.items(), key=lambda x: x[1], reverse=True)[:10]

        # 清空旧记录
        await db.execute(
            delete(LeaderboardEntry).where(LeaderboardEntry.mode == mode)
        )
        # 写入新记录
        for name, score in top10:
            db.add(LeaderboardEntry(mode=mode, username=name, score=score))
        await db.commit()
