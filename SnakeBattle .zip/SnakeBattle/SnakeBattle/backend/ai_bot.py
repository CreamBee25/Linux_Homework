"""AI 人机控制器 — 规则驱动 + 自避让"""

import math
import random

from config import WORLD_WIDTH, WORLD_HEIGHT

W_AVOID_WALL = 120.0
W_AVOID_SNAKE = 100.0
W_AVOID_SELF = 200.0    # 避让自己身体（极高权重）
W_SEEK_FOOD = 15.0
W_RANDOM = 2.0
W_AVOID_BIG = 40.0
W_AVOID_HEAD_ON = 150.0  # 避免头对头

NUM_ANGLES = 24
SAMPLE_DISTS = [60, 150]
VISION = 400


class AIBot:

    def decide(self, snake, all_snakes: list, foods: list) -> tuple:
        if not snake.alive:
            return snake.x, snake.y, False

        hx, hy = snake.head

        # ---- 自己身体的附近段（避让自己）----
        my_segs = [
            seg for i, seg in enumerate(snake.segments)
            if i >= 8 and abs(hx - seg[0]) < 200 and abs(hy - seg[1]) < 200
        ]

        # ---- 预过滤其他蛇 ----
        nearby_snakes = []
        for other in all_snakes:
            if other is snake or not other.alive:
                continue
            ohx, ohy = other.head
            if abs(hx - ohx) < VISION and abs(hy - ohy) < VISION:
                near_segs = [
                    seg for seg in other.segments[2:]  # 跳过对方头部段
                    if abs(hx - seg[0]) < VISION and abs(hy - seg[1]) < VISION
                ]
                nearby_snakes.append((other, near_segs, ohx, ohy))

        nearby_foods = [
            f for f in foods
            if abs(hx - f.x) < VISION and abs(hy - f.y) < VISION
        ]

        # ---- 评估各方向 ----
        best_angle = snake.angle
        best_score = -1e9

        # 当前朝向有加分（避免频繁转向）
        for i in range(NUM_ANGLES):
            angle = (i / NUM_ANGLES) * math.pi * 2
            score = self._eval(angle, hx, hy, snake.length, snake.angle,
                               my_segs, nearby_snakes, nearby_foods)

            if score > best_score:
                best_score = score
                best_angle = angle

        # 转向太猛时减速（用smooth转向）
        angle_diff = best_angle - snake.angle
        while angle_diff > math.pi: angle_diff -= math.pi * 2
        while angle_diff < -math.pi: angle_diff += math.pi * 2
        if abs(angle_diff) > math.pi / 3:  # 超过60度急转
            best_angle = snake.angle + math.copysign(math.pi / 3, angle_diff)

        target_x = hx + math.cos(best_angle) * 200
        target_y = hy + math.sin(best_angle) * 200
        boost = self._should_boost(hx, hy, snake.length, nearby_snakes, nearby_foods)

        return target_x, target_y, boost

    def _eval(self, angle, hx, hy, my_len, cur_angle, my_segs, nearby_snakes, nearby_foods) -> float:
        score = 0.0
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)

        # 保持当前方向的小加分（减少蛇形摆动）
        adiff = abs(angle - cur_angle)
        if adiff > math.pi: adiff = math.pi * 2 - adiff
        if adiff < 0.3:
            score += 5.0

        for dist in SAMPLE_DISTS:
            px = hx + cos_a * dist
            py = hy + sin_a * dist

            # 墙壁
            bw = min(px, WORLD_WIDTH - px, py, WORLD_HEIGHT - py)
            if bw < 150:
                score -= W_AVOID_WALL * (150 - bw) / 150

            # 避让自己身体（最重要）
            for sx, sy in my_segs:
                d2 = (px - sx) ** 2 + (py - sy) ** 2
                if d2 < 6400:  # 80^2
                    d = math.sqrt(d2)
                    score -= W_AVOID_SELF * (80 - d) / 80

            # 其他蛇
            for other, near_segs, ohx, ohy in nearby_snakes:
                # 避让对方头（防头对头）
                d2h = (px - ohx) ** 2 + (py - ohy) ** 2
                if d2h < 10000:  # 100^2
                    score -= W_AVOID_HEAD_ON

                # 避让对方身体
                closest = 99999
                for sx, sy in near_segs:
                    d2 = (px - sx) ** 2 + (py - sy) ** 2
                    if d2 < closest: closest = d2
                if closest < 6400:
                    d = math.sqrt(closest)
                    score -= W_AVOID_SNAKE * (80 - d) / 80

                # 大蛇额外远离
                if other.length > my_len * 1.3:
                    d2h = (px - ohx) ** 2 + (py - ohy) ** 2
                    if d2h < 40000:  # 200^2
                        score -= W_AVOID_BIG

            # 食物
            for food in nearby_foods[:40]:
                d2 = (px - food.x) ** 2 + (py - food.y) ** 2
                if d2 < 3600:  # 60^2
                    score += W_SEEK_FOOD * food.radius / 6

        score += random.uniform(-W_RANDOM, W_RANDOM)
        return score

    def _should_boost(self, hx, hy, my_len, nearby_snakes, nearby_foods) -> bool:
        for other, near_segs, ohx, ohy in nearby_snakes:
            d = math.hypot(hx - ohx, hy - ohy)

            # 大蛇太近 → 逃
            if other.length > my_len * 1.2 and d < 130:
                return True

            # 对方朝向自己 → 躲
            if d < 200:
                atme = math.atan2(hy - ohy, hx - ohx)
                diff = abs(atme - other.angle)
                if diff > math.pi: diff = math.pi * 2 - diff
                if diff < math.pi / 4:
                    return True

            # 小蛇 → 追杀
            if other.length < my_len * 0.55 and d < 200 and my_len > 25:
                return True

        # 密集食物
        cnt = sum(1 for f in nearby_foods[:20]
                  if (hx - f.x) ** 2 + (hy - f.y) ** 2 < 10000)
        if cnt >= 6:
            return True

        return False
