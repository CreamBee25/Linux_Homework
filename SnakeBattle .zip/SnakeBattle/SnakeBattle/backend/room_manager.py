"""房间管理器 — 多房间生命周期管理"""

import asyncio
import random
import string
import time
from dataclasses import dataclass, field

from game_engine import GameEngine

# 易混淆字符排除
_ROOM_CHARS = "ABCDEFGHJKMNPQRTUVWXYZ2346789"
ROOM_CLEANUP_INTERVAL = 30      # 清理检查间隔（秒）
ROOM_IDLE_TIMEOUT = 300         # 空房间空闲超时（秒）
MAX_ROOMS = 50                  # 最大房间数


def generate_room_code(length: int = 6) -> str:
    """生成随机房间码（排除易混淆字符）"""
    return ''.join(random.choices(_ROOM_CHARS, k=length))


@dataclass
class GameRoom:
    """游戏房间"""
    code: str
    engine: GameEngine
    created_at: float = field(default_factory=time.time)
    last_activity: float = field(default_factory=time.time)
    human_count: int = 0          # 真人玩家数
    game_mode: str = "endless"
    mode_config: int = 0

    @property
    def is_empty(self) -> bool:
        return self.human_count <= 0

    @property
    def idle_seconds(self) -> float:
        return time.time() - self.last_activity

    def to_dict(self) -> dict:
        """房间公开信息"""
        alive = sum(1 for s in self.engine.snakes.values() if s.alive)
        return {
            "code": self.code,
            "mode": self.game_mode,
            "players": self.human_count,
            "ai": sum(1 for s in self.engine.snakes.values() if s.is_ai),
            "alive": alive,
            "tick": self.engine.tick,
            "created_ago": int(time.time() - self.created_at),
        }


class RoomManager:
    """房间管理器"""

    def __init__(self):
        self.rooms: dict[str, GameRoom] = {}
        self._cleanup_task: asyncio.Task | None = None

    # ==================== 房间操作 ====================

    def create_room(self, mode: str = "endless", mode_config: int = 0) -> GameRoom:
        """创建新房间"""
        # 检查房间数上限
        if len(self.rooms) >= MAX_ROOMS:
            # 尝试清理空房间腾出位置
            self._cleanup_idle()
            if len(self.rooms) >= MAX_ROOMS:
                raise RuntimeError(f"服务器已满（最多 {MAX_ROOMS} 个房间），请稍后再试")

        # 生成唯一房间码
        code = generate_room_code()
        attempts = 0
        while code in self.rooms and attempts < 50:
            code = generate_room_code()
            attempts += 1
        if code in self.rooms:
            raise RuntimeError("无法生成唯一房间码，请重试")

        # 创建独立游戏引擎
        engine = GameEngine(room_code=code)

        room = GameRoom(
            code=code,
            engine=engine,
            game_mode=mode,
            mode_config=mode_config,
        )
        room.engine.set_mode(mode, mode_config)
        self.rooms[code] = room

        # 异步启动游戏循环（不阻塞）
        asyncio.create_task(self._start_room_engine(room))

        print(f"[ROOM] 创建房间 {code} (mode={mode}, config={mode_config}), 当前共 {len(self.rooms)} 个房间")
        return room

    async def _start_room_engine(self, room: GameRoom):
        """启动房间的游戏引擎"""
        try:
            await room.engine.start()
        except Exception as e:
            print(f"[ROOM] 房间 {room.code} 引擎异常: {type(e).__name__}: {e}")

    def get_room(self, code: str) -> GameRoom | None:
        """获取房间（规范化大小写）"""
        return self.rooms.get(code.upper())

    def list_rooms(self) -> list[dict]:
        """列出所有活跃房间"""
        return [r.to_dict() for r in self.rooms.values()]

    def join_room(self, code: str, snake_id: str, username: str, is_ai: bool = False):
        """玩家加入房间"""
        room = self.get_room(code)
        if room is None:
            raise ValueError(f"房间 {code} 不存在")

        room.last_activity = time.time()
        if not is_ai:
            room.human_count += 1

        snake = room.engine.add_player(snake_id, username, is_ai=is_ai)
        return room, snake

    def leave_room(self, code: str, snake_id: str):
        """玩家离开房间"""
        room = self.get_room(code)
        if room is None:
            return

        snake = room.engine.snakes.get(snake_id)
        was_human = snake is not None and not snake.is_ai

        room.engine.remove_player(snake_id)
        room.last_activity = time.time()

        if was_human:
            room.human_count = max(0, room.human_count - 1)

    # ==================== 生命周期 ====================

    async def start(self):
        """启动房间管理器"""
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
        print("[ROOM] 房间管理器已启动")

    async def stop(self):
        """停止所有房间"""
        if self._cleanup_task:
            self._cleanup_task.cancel()
        # 停止所有游戏循环
        for room in list(self.rooms.values()):
            try:
                await room.engine.stop()
            except Exception as e:
                print(f"[ROOM] 停止房间 {room.code} 失败: {e}")
        self.rooms.clear()
        print("[ROOM] 房间管理器已停止")

    async def _cleanup_loop(self):
        """定时清理空闲房间"""
        while True:
            try:
                await asyncio.sleep(ROOM_CLEANUP_INTERVAL)
                self._cleanup_idle()
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"[ROOM] 清理异常: {e}")

    def _cleanup_idle(self):
        """清理超时空房间"""
        to_remove = []
        for code, room in self.rooms.items():
            if room.is_empty and room.idle_seconds > ROOM_IDLE_TIMEOUT:
                to_remove.append(code)

        for code in to_remove:
            room = self.rooms.pop(code)
            asyncio.create_task(room.engine.stop())
            print(f"[ROOM] 清理空闲房间 {code}（空闲 {int(room.idle_seconds)}s）")

    # ==================== 快速匹配 ====================

    def find_or_create_room(self, mode: str = "endless", mode_config: int = 0) -> GameRoom:
        """快速匹配：找同模式有空位的房间，否则创建新房间"""
        for room in self.rooms.values():
            if (room.game_mode == mode
                    and room.mode_config == mode_config
                    and room.human_count > 0
                    and not room.engine.game_over
                    and room.human_count < 20):  # 每房间最多20真人
                return room
        # 没找到合适的，创建新房间
        return self.create_room(mode, mode_config)


# 全局房间管理器
room_manager = RoomManager()
