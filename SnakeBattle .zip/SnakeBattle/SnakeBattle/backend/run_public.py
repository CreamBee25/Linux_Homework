"""
公网联机启动脚本 — 使用 ngrok 内网穿透让外网好友连接

用法:
  python run_public.py                     # 只用 uvicorn，局域网可连
  python run_public.py --ngrok             # 启动 ngrok，获取公网地址
  NGROK_AUTH_TOKEN=xxx python run_public.py --ngrok  # 带认证 token

前提: pip install pyngrok
"""

import argparse
import os
import subprocess
import sys
import time


def start_ngrok(port: int = 8000):
    """启动 ngrok 隧道，返回公网地址"""
    try:
        from pyngrok import ngrok, conf
    except ImportError:
        print("[ERR] 请先安装 pyngrok: pip install pyngrok")
        print("[INFO] 或者访问 https://ngrok.com 下载 ngrok 手动使用")
        return None

    auth_token = os.getenv("NGROK_AUTH_TOKEN", "")
    if auth_token:
        conf.get_default().auth_token = auth_token
        print("[NGROK] 已设置认证 token")

    try:
        # 创建 HTTP 隧道
        tunnel = ngrok.connect(port, "http")
        url = tunnel.public_url
        print("=" * 55)
        print(f"  🌐 公网地址（发给好友即可联机！）")
        print(f"  {url}")
        print(f"  房间码在游戏中创建房间后显示")
        print("=" * 55)
        return url
    except Exception as e:
        print(f"[NGROK] 启动失败: {e}")
        print("[INFO] 可能的原因：")
        print("  1. 未登录 ngrok 账号（免费注册: https://dashboard.ngrok.com/signup）")
        print("  2. 未设置 NGROK_AUTH_TOKEN 环境变量")
        print("  3. 网络问题无法连接 ngrok 服务")
        return None


def main():
    parser = argparse.ArgumentParser(description="🐍 贪吃蛇大作战 — 公网联机启动")
    parser.add_argument("--ngrok", action="store_true", help="启用 ngrok 内网穿透")
    parser.add_argument("--port", type=int, default=8000, help="服务端口（默认 8000）")
    parser.add_argument("--host", default="0.0.0.0", help="绑定地址")
    args = parser.parse_args()

    ngrok_url = None
    if args.ngrok:
        ngrok_url = start_ngrok(args.port)
        if ngrok_url is None:
            print("[WARN] ngrok 启动失败，仅使用本地服务")

    print()
    print(f"[SRV] 启动游戏服务器: http://{args.host}:{args.port}")
    print("[SRV] 按 Ctrl+C 停止")
    print()

    try:
        import uvicorn
        uvicorn.run(
            "main:app",
            host=args.host,
            port=args.port,
            log_level="info",
        )
    except KeyboardInterrupt:
        print("\n[SRV] 服务器已停止")


if __name__ == "__main__":
    main()
