"""贪吃蛇大作战 — 桌面启动器（一键启动游戏服务）"""
import socket
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk

import uvicorn


def get_local_ip() -> str:
    """获取本机局域网 IP"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def get_wifi_ssid() -> str:
    """尝试获取当前 WiFi 名称（Windows）"""
    try:
        result = subprocess.run(
            ["netsh", "wlan", "show", "interfaces"],
            capture_output=True, text=True, timeout=5,
            encoding="utf-8", errors="ignore"
        )
        for line in result.stdout.splitlines():
            if "SSID" in line and "BSSID" not in line:
                return line.split(":")[-1].strip()
    except Exception:
        pass
    return ""


class GameLauncher:
    """游戏启动器 GUI"""

    def __init__(self):
        self.server_thread = None
        self.server_running = False
        self.port = 8000

        self.root = tk.Tk()
        self.root.title("🐍 贪吃蛇大作战 — 启动器")
        self.root.geometry("420x460")
        self.root.resizable(False, False)
        self.root.configure(bg="#1a1a2e")

        self.root.eval("tk::PlaceWindow . center")

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(500, self._detect_existing)

    def _build_ui(self):
        bg = "#1a1a2e"
        fg = "#ffffff"

        title = tk.Label(
            self.root, text="🐍 贪吃蛇大作战",
            font=("Microsoft YaHei", 20, "bold"),
            fg=fg, bg=bg
        )
        title.pack(pady=(24, 4))

        sub = tk.Label(
            self.root, text="多人实时在线对战",
            font=("Microsoft YaHei", 11),
            fg="gray", bg=bg
        )
        sub.pack(pady=(0, 20))

        self.status_canvas = tk.Canvas(self.root, width=16, height=16, bg=bg, highlightthickness=0)
        self.status_canvas.pack()
        self.status_dot = self.status_canvas.create_oval(2, 2, 14, 14, fill="#555", outline="")

        self.status_label = tk.Label(
            self.root, text="未启动",
            font=("Microsoft YaHei", 13, "bold"),
            fg="#888", bg=bg
        )
        self.status_label.pack(pady=(4, 16))

        self.start_btn = tk.Button(
            self.root, text="🚀 启 动 游 戏",
            font=("Microsoft YaHei", 14, "bold"),
            bg="#4488ee", fg="white",
            activebackground="#5599ff", activeforeground="white",
            relief="flat", padx=32, pady=10,
            cursor="hand2",
            command=self._toggle_server
        )
        self.start_btn.pack(pady=(0, 12))

        self.url_frame = tk.Frame(self.root, bg="#0d0d20", padx=2, pady=2)
        self.url_frame.pack(fill="x", padx=40)

        self.url_text = tk.Text(
            self.url_frame,
            font=("Consolas", 11),
            fg="#44ff66", bg="#0d0d20",
            height=3, width=38,
            relief="flat",
            borderwidth=0,
            state="disabled"
        )
        self.url_text.pack(fill="x")
        self._update_url_display()

        self.copy_btn = tk.Button(
            self.root, text="📋 复制链接",
            font=("Microsoft YaHei", 10),
            bg="#2a2a40", fg="#ccc",
            activebackground="#3a3a50",
            relief="flat", padx=16, pady=4,
            cursor="hand2",
            state="disabled",
            command=self._copy_url
        )
        self.copy_btn.pack(pady=(8, 20))

        info_frame = tk.Frame(self.root, bg=bg)
        info_frame.pack(fill="x", padx=40)

        ip = get_local_ip()
        wifi = get_wifi_ssid()
        tk.Label(
            info_frame,
            text=f"🖥️ 本机 IP: {ip}",
            font=("Microsoft YaHei", 10),
            fg="#aaa", bg=bg
        ).pack(anchor="w")

        if wifi:
            tk.Label(
                info_frame,
                text=f"📶 WiFi: {wifi}",
                font=("Microsoft YaHei", 10),
                fg="#aaa", bg=bg
            ).pack(anchor="w")

        tk.Label(
            info_frame,
            text="同一 WiFi 下的设备可加入游戏",
            font=("Microsoft YaHei", 9),
            fg="#666", bg=bg
        ).pack(anchor="w", pady=(4, 0))

        tk.Label(
            self.root, text="手机扫码或浏览器打开上面的地址即可联机",
            font=("Microsoft YaHei", 9),
            fg="#555", bg=bg
        ).pack(side="bottom", pady=12)

    def _update_url_display(self):
        ip = get_local_ip()
        self.url_text.configure(state="normal")
        self.url_text.delete(1.0, "end")
        lines = [
            f"  本机访问: http://localhost:{self.port}",
            f"  局域网:   http://{ip}:{self.port}",
        ]
        self.url_text.insert(1.0, "\n".join(lines))
        self.url_text.configure(state="disabled")

    def _set_status(self, running: bool):
        if running:
            self.status_canvas.itemconfig(self.status_dot, fill="#44ff66")
            self.status_label.configure(text="运行中", fg="#44ff66")
            self.start_btn.configure(text="⏹ 停 止 服 务", bg="#dd4444")
            self.copy_btn.configure(state="normal")
        else:
            self.status_canvas.itemconfig(self.status_dot, fill="#555")
            self.status_label.configure(text="未启动", fg="#888")
            self.start_btn.configure(text="🚀 启 动 游 戏", bg="#4488ee")
            self.copy_btn.configure(state="disabled")

    def _toggle_server(self):
        if self.server_running:
            self._stop_server()
        else:
            self._start_server()

    def _open_firewall(self) -> bool:
        """尝试为游戏端口添加 Windows 防火墙规则"""
        try:
            result = subprocess.run(
                [
                    "netsh", "advfirewall", "firewall", "add", "rule",
                    "name=SnakeBattle",
                    "dir=in",
                    "action=allow",
                    "protocol=TCP",
                    f"localport={self.port}",
                    "profile=any",
                ],
                capture_output=True, text=True, timeout=10
            )
            return result.returncode == 0 or "确定" in result.stdout
        except Exception:
            return False

    def _start_server(self):
        self._set_status(True)
        self.server_running = True

        self._open_firewall()

        def run():
            try:
                uvicorn.run(
                    "main:app",
                    host="0.0.0.0",
                    port=self.port,
                    log_level="warning",
                )
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("错误", f"启动失败: {e}"))
                self.root.after(0, self._stop_server)

        self.server_thread = threading.Thread(target=run, daemon=True)
        self.server_thread.start()

        self.root.after(2000, self._check_started)

    def _check_started(self):
        if not self.server_running:
            return
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1)
            s.connect(("127.0.0.1", self.port))
            s.close()
            self._update_url_display()
        except Exception:
            self.root.after(1500, self._check_started)

    def _stop_server(self):
        self.server_running = False

        pid = self._find_port_pid(self.port)
        if pid:
            try:
                subprocess.run(["taskkill", "/F", "/PID", str(pid)],
                               capture_output=True, timeout=5)
                time.sleep(0.5)
            except Exception:
                pass

        self.server_thread = None
        self._set_status(False)
        self._update_url_display()

    def _find_port_pid(self, port: int) -> int | None:
        try:
            result = subprocess.run(
                ["netstat", "-ano"],
                capture_output=True, text=True, timeout=5
            )
            for line in result.stdout.splitlines():
                if f":{port}" in line and "LISTENING" in line:
                    parts = line.strip().split()
                    return int(parts[-1])
        except Exception:
            pass
        return None

    def _copy_url(self):
        ip = get_local_ip()
        url = f"http://{ip}:{self.port}"
        self.root.clipboard_clear()
        self.root.clipboard_append(url)
        messagebox.showinfo("已复制", f"链接已复制到剪贴板：\n{url}")

    def _detect_existing(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.5)
            s.connect(("127.0.0.1", self.port))
            s.close()
            self.server_running = True
            self._set_status(True)
            self._update_url_display()
        except Exception:
            pass

    def _on_close(self):
        if self.server_running:
            if messagebox.askyesno("确认", "服务器正在运行，确定要退出吗？"):
                self._stop_server()
                self.root.destroy()
        else:
            self.root.destroy()

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    import os
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    GameLauncher().run()
