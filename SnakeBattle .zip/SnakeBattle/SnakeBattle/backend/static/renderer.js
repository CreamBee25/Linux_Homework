/**
 * Canvas 渲染引擎 — 客户端预测平滑 + 身体波动画
 */

class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.camera = { x: 2000, y: 2000, zoom: 1.0 };
    this.worldW = 4000;
    this.worldH = 4000;
    this.particles = [];
    this._starCanvas = null;
    this._needsStars = true;
    this.lowPerf = false;  // 低性能模式（手机端）

    // 客户端预测缓存：记录每条蛇的上次头部位置和角度
    this._snakeCache = {};  // {id: {hx, hy, angle, speed, time}}

    this.resize();
    window.addEventListener('resize', () => { this.resize(); this._needsStars = true; });
  }

  resize() {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
  }

  // ==================== 星空背景 ====================

  _drawStars() {
    if (!this._needsStars && this._starCanvas) return;

    try {
      // 限制最大尺寸，手机端避免内存不足
      var w = Math.min(Math.max(this.canvas.width, 800), 1920);
      var h = Math.min(Math.max(this.canvas.height, 600), 1080);
      var sc = document.createElement('canvas');
      sc.width = w;
      sc.height = h;
      var sctx = sc.getContext('2d');
      if (!sctx) { this._starCanvas = null; this._needsStars = false; return; }

      var grad = sctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, Math.max(w, h) * 0.7);
      grad.addColorStop(0, '#1a1a3e');
      grad.addColorStop(0.5, '#12122a');
      grad.addColorStop(1, '#0a0a18');
      sctx.fillStyle = grad;
      sctx.fillRect(0, 0, w, h);
      for (var i = 0; i < 200; i++) {
        sctx.fillStyle = 'rgba(255,255,255,' + (Math.random() * 0.6 + 0.2) + ')';
        sctx.beginPath(); sctx.arc(Math.random() * w, Math.random() * h, Math.random() * 1.5 + 0.3, 0, Math.PI * 2); sctx.fill();
      }
      for (var i = 0; i < 8; i++) {
        var x = Math.random() * w, y = Math.random() * h, r = Math.random() * 1.2 + 0.8;
        sctx.fillStyle = 'rgba(180,200,255,0.8)';
        sctx.beginPath(); sctx.arc(x, y, r, 0, Math.PI * 2); sctx.fill();
        sctx.fillStyle = 'rgba(180,200,255,0.2)';
        sctx.beginPath(); sctx.arc(x, y, r * 3, 0, Math.PI * 2); sctx.fill();
      }
      this._starCanvas = sc;
      this._needsStars = false;
    } catch (e) {
      console.warn('[Renderer] Star background failed, using solid color:', e.message);
      this._starCanvas = null;  // 回退到纯色背景
      this._needsStars = false;
    }
  }

  // ==================== 坐标 ====================

  screenToWorld(sx, sy) {
    return {
      x: (sx - this.canvas.width / 2) / this.camera.zoom + this.camera.x,
      y: (sy - this.canvas.height / 2) / this.camera.zoom + this.camera.y,
    };
  }

  updateCamera(px, py, len) {
    this.camera.x += (px - this.camera.x) * 0.12;
    this.camera.y += (py - this.camera.y) * 0.12;
    this.camera.zoom += (Math.max(0.55, 1.0 - (len - 15) * 0.0025) - this.camera.zoom) * 0.06;
  }

  // ==================== 主渲染 ====================

  render(state, playerId) {
    var ctx = this.ctx;
    if (!ctx) return;
    var w = this.canvas.width, h = this.canvas.height;
    if (!w || !h) return;
    var now = performance.now() / 1000;

    // 背景（星空图失败则纯色回退）
    this._drawStars();
    if (this._starCanvas) {
      ctx.drawImage(this._starCanvas, 0, 0, w, h);
    } else {
      ctx.fillStyle = '#0a0a18';
      ctx.fillRect(0, 0, w, h);
    }

    ctx.save();
    ctx.translate(w / 2, h / 2);
    ctx.scale(this.camera.zoom, this.camera.zoom);
    ctx.translate(-this.camera.x, -this.camera.y);

    this._drawGrid(ctx);
    this._drawBoundary(ctx);

    // 食物
    var foods = state.foods;
    if (foods && foods.length) {
      for (var fi = 0; fi < foods.length; fi++) {
        this._drawFood(ctx, foods[fi]);
      }
    }

    // 蛇（带客户端预测）— 每条蛇独立容错
    var snakes = state.snakes;
    if (snakes && snakes.length) {
      for (var si = 0; si < snakes.length; si++) {
        try {
          this._drawSnakePredicted(ctx, snakes[si], snakes[si].id === playerId, now);
        } catch (e) {}
      }
    }

    // 粒子
    var particles = this.particles;
    for (var pi = 0; pi < particles.length; pi++) {
      var p = particles[pi];
      ctx.fillStyle = 'rgba(255,255,255,' + (p.life * 0.7) + ')';
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r * p.life, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
    this._updateParticles();
  }

  // ==================== 网格 / 边界 / 食物 ====================

  _drawGrid(ctx) {
    var gs = this.lowPerf ? 200 : 100;  // 手机端加粗网格减少绘制量
    var left = this.camera.x - this.canvas.width / 2 / this.camera.zoom;
    var top = this.camera.y - this.canvas.height / 2 / this.camera.zoom;
    var right = this.camera.x + this.canvas.width / 2 / this.camera.zoom;
    var bottom = this.camera.y + this.canvas.height / 2 / this.camera.zoom;
    ctx.strokeStyle = 'rgba(255,255,255,0.025)';
    ctx.lineWidth = 1; ctx.beginPath();
    for (var x = Math.floor(left / gs) * gs; x <= right; x += gs) { ctx.moveTo(x, top); ctx.lineTo(x, bottom); }
    for (var y = Math.floor(top / gs) * gs; y <= bottom; y += gs) { ctx.moveTo(left, y); ctx.lineTo(right, y); }
    ctx.stroke();
  }

  _drawBoundary(ctx) {
    ctx.strokeStyle = 'rgba(255,40,40,0.15)'; ctx.lineWidth = 30;
    ctx.strokeRect(-15, -15, this.worldW + 30, this.worldH + 30);
    ctx.strokeStyle = '#e04040'; ctx.lineWidth = 5;
    ctx.strokeRect(0, 0, this.worldW, this.worldH);
  }

  _drawFood(ctx, f) {
    var r = f.r || 3;
    if (this.lowPerf) {
      // 手机端简化：只画纯色圆 + 小高光点
      ctx.fillStyle = f.c || '#FFDD44';
      ctx.beginPath(); ctx.arc(f.x, f.y, r, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.3)';
      ctx.beginPath(); ctx.arc(f.x - r * 0.2, f.y - r * 0.2, r * 0.35, 0, Math.PI * 2); ctx.fill();
    } else {
      var g = ctx.createRadialGradient(f.x, f.y, r * 0.2, f.x, f.y, r * 2.5);
      g.addColorStop(0, 'rgba(255,255,200,0.4)'); g.addColorStop(0.5, 'rgba(255,200,80,0.1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(f.x, f.y, r * 3, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = f.c || '#FFDD44'; ctx.beginPath(); ctx.arc(f.x, f.y, r, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.beginPath();
      ctx.arc(f.x - r * 0.3, f.y - r * 0.3, r * 0.45, 0, Math.PI * 2); ctx.fill();
    }
  }

  // ==================== 蛇 — 客户端预测 + 大波浪 ====================

  _drawSnakePredicted(ctx, snake, isPlayer, now) {
    var segs = snake.segments;
    if (!segs || segs.length < 2) return;

    // --- 客户端预测 ---
    var cache = this._snakeCache[snake.id];
    var head = segs[0];

    // 计算速度（px/秒）
    var vx = 0, vy = 0;
    if (cache) {
      var dt = now - cache.time;
      if (dt > 0.01 && dt < 0.5) {
        var dx = head.x - cache.hx, dy = head.y - cache.hy;
        if (Math.abs(dx) < 50 && Math.abs(dy) < 50) {
          vx = dx / dt; vy = dy / dt;
        }
      }
    }
    // 更新缓存
    this._snakeCache[snake.id] = { hx: head.x, hy: head.y, angle: snake.angle || 0, time: now };

    // 预测偏移量
    var predTime = now - (cache ? cache.time : now);
    var predX = vx * Math.min(predTime, 0.1);
    var predY = vy * Math.min(predTime, 0.1);

    // --- 绘制 ---
    var color = snake.color || '#44FF44';
    var len = snake.length || segs.length;
    var bodyR = 4.5 + Math.min(len * 0.38, 28);
    var a = snake.angle || 0;
    var perpX = Math.cos(a + Math.PI / 2);
    var perpY = Math.sin(a + Math.PI / 2);
    var waveSpeed = 10;
    var waveAmp = bodyR * 0.35;

    // --- 身体段 ---
    var segGap = bodyR * 0.15;
    var segR = bodyR - segGap;
    var low = this.lowPerf;

    for (var i = segs.length - 1; i >= 0; i--) {
      var t = i / Math.max(1, segs.length - 1);
      var offset = Math.sin(now * waveSpeed - i * 0.6) * waveAmp * 0.5 * Math.min(t * 1.5, 1);
      var sx = segs[i].x + perpX * offset + predX * t;
      var sy = segs[i].y + perpY * offset + predY * t;

      // 段底色
      var alpha = 0.55 + 0.45 * t;
      ctx.fillStyle = this._alpha(color, alpha);
      ctx.beginPath();
      ctx.arc(sx, sy, segR, 0, Math.PI * 2);
      ctx.fill();

      if (!low) {
        // 段描边
        ctx.strokeStyle = this._alpha(color, Math.min(1, alpha + 0.2));
        ctx.lineWidth = bodyR * 0.18;
        ctx.stroke();
        // 高光点
        ctx.fillStyle = 'rgba(255,255,255,' + (0.2 + 0.15 * Math.sin(now * 5 + i * 0.7)) * (1 - t * 0.5) + ')';
        ctx.beginPath();
        ctx.arc(sx - segR * 0.25, sy - segR * 0.25, segR * 0.3, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 尾部收尖（手机端跳过）
    if (!low && segs.length > 3) {
      for (var i = segs.length - 1; i >= Math.max(0, segs.length - 3); i--) {
        var p = (segs.length - 1 - i) / 3;
        var r = segR * (1 - p * 0.7);
        var t = i / Math.max(1, segs.length - 1);
        var offset = Math.sin(now * waveSpeed - i * 0.6) * waveAmp * 0.3;
        var sx = segs[i].x + perpX * offset + predX * t;
        var sy = segs[i].y + perpY * offset + predY * t;
        ctx.fillStyle = this._alpha(color, 0.35 + 0.35 * (1 - p));
        ctx.beginPath();
        ctx.arc(sx, sy, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = this._alpha(color, 0.5);
        ctx.lineWidth = r * 0.18;
        ctx.stroke();
      }
    }

    // --- 头部 ---
    var headR = segR * 1.25;
    var hx = head.x + predX, hy = head.y + predY;

    if (!low) {
      // 头光晕
      var glow = ctx.createRadialGradient(hx, hy, headR * 0.3, hx, hy, headR * 1.6);
      glow.addColorStop(0, 'rgba(255,255,255,0.2)'); glow.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(hx, hy, headR * 1.6, 0, Math.PI * 2); ctx.fill();
    }

    // 头主体
    ctx.fillStyle = color; ctx.beginPath(); ctx.arc(hx, hy, headR, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = this._alpha(color, 0.8);
    ctx.lineWidth = headR * 0.2;
    ctx.stroke();

    if (!low) {
      // 头高光
      ctx.fillStyle = 'rgba(255,255,255,0.2)';
      ctx.beginPath(); ctx.arc(hx - headR * 0.2, hy - headR * 0.25, headR * 0.35, 0, Math.PI * 2); ctx.fill();
    }

    // 眼睛
    var ex = Math.cos(a) * headR * 0.25, ey = Math.sin(a) * headR * 0.25;
    var ppx = Math.cos(a + Math.PI / 2) * headR * 0.45, ppy = Math.sin(a + Math.PI / 2) * headR * 0.45;
    for (var side = -1; side <= 1; side += 2) {
      var e2x = hx + ex + ppx * side, e2y = hy + ey + ppy * side;
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(e2x, e2y, headR * 0.32, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#111'; ctx.beginPath();
      ctx.arc(e2x + Math.cos(a) * headR * 0.1, e2y + Math.sin(a) * headR * 0.1, headR * 0.15, 0, Math.PI * 2);
      ctx.fill();
    }

    // 名字（手机端只显示自己）
    if (snake.username && (isPlayer || (!low && len > 20))) {
      ctx.fillStyle = '#fff';
      ctx.font = 'bold ' + Math.min(11 + len * 0.18, 17) + 'px sans-serif';
      ctx.textAlign = 'center';
      ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 3;
      ctx.fillText(snake.username, hx, hy - headR - 12);
      ctx.shadowBlur = 0;
    }

    // 加速特效（手机端减少）
    var boostParticles = low ? 2 : 4;
    if (snake.boost) {
      for (var i = 0; i < boostParticles; i++) {
        ctx.fillStyle = 'rgba(255,255,255,' + (0.25 - i * 0.06) + ')';
        ctx.beginPath();
        ctx.arc(hx - Math.cos(a) * (8 + i * 6), hy - Math.sin(a) * (8 + i * 6),
                headR * (0.5 - i * 0.1), 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  // ==================== 粒子 ====================

  spawnParticles(x, y, color, count) {
    for (var i = 0; i < (count || 12); i++) {
      var a = Math.random() * Math.PI * 2;
      var sp = 1.5 + Math.random() * 5;
      this.particles.push({
        x: x, y: y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
        life: 1, decay: 0.02 + Math.random() * 0.05, color: color, r: 2 + Math.random() * 4,
      });
    }
  }

  _updateParticles() {
    for (var pi = 0; pi < this.particles.length; pi++) {
      var p = this.particles[pi];
      p.x += p.vx; p.y += p.vy; p.life -= p.decay;
    }
    this.particles = this.particles.filter(function(p) { return p.life > 0; });
  }

  // ==================== 小地图 ====================

  drawMiniMap(canvas, snakes, px, py) {
    var ctx = canvas.getContext('2d');
    var mw = canvas.width, mh = canvas.height;
    var sx = mw / this.worldW, sy = mh / this.worldH;
    ctx.fillStyle = 'rgba(5,5,20,0.75)'; ctx.fillRect(0, 0, mw, mh);
    ctx.strokeStyle = 'rgba(255,60,60,0.6)'; ctx.lineWidth = 1.5; ctx.strokeRect(0, 0, mw, mh);
    for (var si = 0; si < snakes.length; si++) {
      var s = snakes[si];
      var h = s.segments && s.segments[0];
      if (!h) continue;
      ctx.fillStyle = s.color; ctx.beginPath();
      ctx.arc(h.x * sx, h.y * sy, 2.5, 0, Math.PI * 2); ctx.fill();
    }
    if (px !== undefined) {
      ctx.fillStyle = '#fff'; ctx.strokeStyle = '#000'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(px * sx, py * sy, 4.5, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    }
  }

  _alpha(hex, a) {
    var r = parseInt(hex.slice(1, 3), 16);
    var g = parseInt(hex.slice(3, 5), 16);
    var b = parseInt(hex.slice(5, 7), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + Math.max(0, Math.min(1, a)) + ')';
  }

  // ==================== 虚拟摇杆（手机端） ====================

  drawMobileUI(joystickState, boostActive) {
    // 加速按钮常驻右下角
    this._drawBoostBtn(!!boostActive);

    // 摇杆仅触摸时显示
    if (joystickState && joystickState.active) {
      this._drawJoystick(joystickState);
    }
  }

  _drawJoystick(st) {
    var ctx = this.ctx;
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);

    var baseX = st.baseX, baseY = st.baseY;
    var nubX = st.nubX, nubY = st.nubY;
    var baseR = 70, nubR = 32;

    // 底座
    ctx.fillStyle = 'rgba(255,255,255,0.08)';
    ctx.strokeStyle = 'rgba(255,255,255,0.2)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(baseX, baseY, baseR, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // 摇杆头
    var grad = ctx.createRadialGradient(nubX - nubR * 0.2, nubY - nubR * 0.2, nubR * 0.1, nubX, nubY, nubR);
    grad.addColorStop(0, 'rgba(255,255,255,0.45)');
    grad.addColorStop(1, 'rgba(255,255,255,0.1)');
    ctx.fillStyle = grad;
    ctx.strokeStyle = 'rgba(255,255,255,0.35)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(nubX, nubY, nubR, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.restore();
  }

  _drawBoostBtn(active) {
    var ctx = this.ctx;
    var w = this.canvas.width, h = this.canvas.height;
    var cx = w - 80, cy = h - 80, r = 48;

    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);

    var alpha = active ? 0.35 : 0.12;
    ctx.fillStyle = 'rgba(255,180,40,' + alpha + ')';
    ctx.strokeStyle = 'rgba(255,180,40,' + (active ? 0.6 : 0.2) + ')';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // ⚡ 图标
    ctx.fillStyle = 'rgba(255,220,100,' + (active ? 0.9 : 0.4) + ')';
    ctx.font = 'bold 28px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('⚡', cx, cy);

    ctx.restore();
  }
}
