/**
 * 游戏客户端 — WebSocket 连接、输入处理、状态管理（房间支持）
 */

class GameClient {
  constructor() {
    this.ws = null;
    this.snakeId = null;
    this.playerSnake = null;
    this.gameState = null;
    this.connected = false;
    this.dead = false;
    this._inputTimer = null;

    // 房间
    this.roomCode = null;
    this.roomType = 'create';  // create | join | quick
    this._roomCreated = false;  // 房间是否已通过 API 创建

    // 输入
    this.mouseX = window.innerWidth / 2;
    this.mouseY = window.innerHeight / 2;

    // 插值平滑（防抖动）
    this.prevState = null;
    this.currentState = null;
    this.stateTime = 0;
    this.prevStateTime = 0;
    this.renderState = null;

    // 渲染
    this.canvas = document.getElementById('gameCanvas');
    this.renderer = new Renderer(this.canvas);

    // UI 元素
    this.miniMap = document.getElementById('miniMap');
    this.joinPanel = document.getElementById('joinPanel');
    this.hud = document.getElementById('hud');
    this.deathPanel = document.getElementById('deathPanel');
    this.deathStats = document.getElementById('deathStats');
    this.lbList = document.getElementById('lbList');
    this.scoreDisplay = document.getElementById('scoreDisplay');
    this.boostBar = document.getElementById('boostBar');
    this.notification = document.getElementById('notification');
    this.usernameInput = document.getElementById('usernameInput');
    this.joinBtn = document.getElementById('joinBtn');
    this.restartBtn = document.getElementById('restartBtn');
    this.sensitivitySlider = document.getElementById('sensitivitySlider');
    this.sensValue = document.getElementById('sensValue');
    this.controlMode = document.getElementById('controlMode');
    this.sensitivity = 1.0;
    this.useWASD = false;
    this.boosting = false;

    // 游戏模式
    this.gameMode = 'endless';
    this.modeConfig = 0;

    // WASD 状态
    this._keys = { w: false, a: false, s: false, d: false };

    // 虚拟摇杆（手机端）
    this._isTouchDevice = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
    if (this._isTouchDevice) {
      var dt = document.getElementById('tipsDesktop');
      var mt = document.getElementById('tipsMobile');
      if (dt) dt.style.display = 'none';
      if (mt) mt.style.display = '';
      // 启用低性能渲染模式
      if (this.renderer) this.renderer.lowPerf = true;
    }
    this.joystick = {
      active: false,
      baseX: 0, baseY: 0,
      nubX: 0, nubY: 0,
      dirX: 0, dirY: 0,
    };
    this.boostBtnActive = false;
    this._joystickTouchId = null;
    this._boostTouchId = null;

    this.lastLeaderboard = null;
    this.animFrameId = null;

    console.log('[Game] Client initialized, binding events...');
    this._bindEvents();
    console.log('[Game] Ready. 选择一个房间模式开始吧！');
  }

  // ==================== 事件绑定 ====================

  _bindEvents() {
    if (this.joinBtn) {
      this.joinBtn.addEventListener('click', () => {
        console.log('[Game] Join button clicked, roomType:', this.roomType);
        this._joinGame();
      });
    }
    if (this.usernameInput) {
      this.usernameInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { console.log('[Game] Enter key pressed'); this._joinGame(); }
      });
    }

    // 房间类型选项卡
    var self = this;
    var roomTabs = document.querySelectorAll('.room-tab');
    if (roomTabs.length) {
      roomTabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
          document.querySelectorAll('.room-tab').forEach(function(t) { t.classList.remove('active'); });
          tab.classList.add('active');
          self.roomType = tab.dataset.room;
          self._updateRoomUI();
        });
      });
    }

    // 房间码输入
    var roomCodeInput = document.getElementById('roomCodeInput');
    if (roomCodeInput) {
      roomCodeInput.addEventListener('input', function() {
        this.value = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
      });
    }

    // 复制房间码按钮（加入面板）
    var copyBtn = document.getElementById('copyRoomBtn');
    if (copyBtn) copyBtn.addEventListener('click', function() { self._copyRoomCode(); });

    // 模式选项卡
    var modeTabs = document.querySelectorAll('.mode-tab');
    if (modeTabs.length) {
      modeTabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
          document.querySelectorAll('.mode-tab').forEach(function(t) { t.classList.remove('active'); });
          tab.classList.add('active');
          self.gameMode = tab.dataset.mode;
          var timedEl = document.getElementById('timedOptions');
          var scoreEl = document.getElementById('scoreOptions');
          if (timedEl) timedEl.style.display = (self.gameMode === 'timed') ? 'block' : 'none';
          if (scoreEl) scoreEl.style.display = (self.gameMode === 'score') ? 'block' : 'none';
        });
      });
    }

    // 返回主菜单
    var backBtn = document.getElementById('backToMenuBtn');
    if (backBtn) backBtn.addEventListener('click', function() { location.reload(); });

    if (this.restartBtn) this.restartBtn.addEventListener('click', () => this._restart());

    // 鼠标
    if (this.canvas) {
      this.canvas.addEventListener('mousemove', (e) => { this.mouseX = e.clientX; this.mouseY = e.clientY; });
      this.canvas.addEventListener('mousedown', (e) => { if (e.button === 0) this.boosting = true; });
      this.canvas.addEventListener('mouseup', (e) => { if (e.button === 0) this.boosting = false; });
    }

    // 触屏：虚拟摇杆（手机端）
    this._bindTouchJoystick();

    // 操控方式切换
    if (this.controlMode) {
      this.controlMode.addEventListener('change', () => {
        this.useWASD = this.controlMode.value === 'wasd';
      });
    }

    // 键盘
    window.addEventListener('keydown', (e) => {
      if (e.code === 'Space') {
        e.preventDefault();
        if (this.dead) { this._restart(); }
        else { this.boosting = true; }
      }
      var k = e.key.toLowerCase();
      if (k in this._keys) { e.preventDefault(); this._keys[k] = true; }
    });
    window.addEventListener('keyup', (e) => {
      if (e.code === 'Space') this.boosting = false;
      var k = e.key.toLowerCase();
      if (k in this._keys) { this._keys[k] = false; }
    });

    // 灵敏度滑块
    if (this.sensitivitySlider) {
      this.sensitivitySlider.addEventListener('input', () => {
        this.sensitivity = parseFloat(this.sensitivitySlider.value);
        if (this.sensValue) this.sensValue.textContent = this.sensitivity.toFixed(1) + 'x';
      });
    }

    window.addEventListener('resize', () => this.renderer.resize());

    window.addEventListener('error', (e) => {
      console.error('[Global]', e.message, e.filename, e.lineno);
    });
  }

  _updateRoomUI() {
    var codeSection = document.getElementById('roomCodeSection');
    var codeDisplay = document.getElementById('roomCodeDisplay');
    var joinBtn = document.getElementById('joinBtn');
    var modeTabs = document.querySelector('.mode-tabs');
    var timedOpts = document.getElementById('timedOptions');
    var scoreOpts = document.getElementById('scoreOptions');

    // 切换房间类型时重置创建状态
    this._roomCreated = false;

    if (this.roomType === 'join') {
      // 加入房间：显示房间码输入，隐藏模式选择（模式由房主决定）
      if (codeSection) codeSection.style.display = 'block';
      if (codeDisplay) codeDisplay.style.display = 'none';
      if (joinBtn) joinBtn.textContent = '加 入 房 间';
      if (modeTabs) modeTabs.style.display = 'none';
      if (timedOpts) timedOpts.style.display = 'none';
      if (scoreOpts) scoreOpts.style.display = 'none';
    } else if (this.roomType === 'quick') {
      // 快速匹配：显示模式选择，隐藏房间码
      if (codeSection) codeSection.style.display = 'none';
      if (codeDisplay) codeDisplay.style.display = 'none';
      if (joinBtn) joinBtn.textContent = '开 始 匹 配';
      if (modeTabs) modeTabs.style.display = '';
      if (timedOpts) timedOpts.style.display = (this.gameMode === 'timed') ? 'block' : 'none';
      if (scoreOpts) scoreOpts.style.display = (this.gameMode === 'score') ? 'block' : 'none';
    } else {
      // 创建房间：显示模式选择，隐藏房间码输入
      if (codeSection) codeSection.style.display = 'none';
      if (codeDisplay) codeDisplay.style.display = 'none';
      if (joinBtn) joinBtn.textContent = '创 建 房 间';
      if (modeTabs) modeTabs.style.display = '';
      if (timedOpts) timedOpts.style.display = (this.gameMode === 'timed') ? 'block' : 'none';
      if (scoreOpts) scoreOpts.style.display = (this.gameMode === 'score') ? 'block' : 'none';
    }
  }

  // ==================== 全屏 ====================

  _requestFullscreen() {
    var el = document.documentElement;
    if (el.requestFullscreen) {
      el.requestFullscreen().catch(function() {});
    } else if (el.webkitRequestFullscreen) {
      el.webkitRequestFullscreen();
    } else if (el.msRequestFullscreen) {
      el.msRequestFullscreen();
    }
    // 同时尝试锁定屏幕方向为横屏
    try {
      if (screen.orientation && screen.orientation.lock) {
        screen.orientation.lock('landscape').catch(function() {});
      }
    } catch (e) {}
  }

  // ==================== 虚拟摇杆（手机端） ====================

  _bindTouchJoystick() {
    if (!this._isTouchDevice) return;

    var self = this;
    var cv = this.canvas;

    cv.addEventListener('touchstart', function(e) {
      e.preventDefault();
      for (var i = 0; i < e.changedTouches.length; i++) {
        var t = e.changedTouches[i];
        var midX = window.innerWidth / 2;

        if (t.clientX < midX && self._joystickTouchId === null) {
          // 左半屏 → 摇杆
          self._joystickTouchId = t.identifier;
          self.joystick.active = true;
          self.joystick.baseX = t.clientX;
          self.joystick.baseY = t.clientY;
          self.joystick.nubX = t.clientX;
          self.joystick.nubY = t.clientY;
          self.joystick.dirX = 0;
          self.joystick.dirY = 0;
        } else if (t.clientX >= midX && self._boostTouchId === null) {
          // 右半屏 → 加速
          self._boostTouchId = t.identifier;
          self.boostBtnActive = true;
          self.boosting = true;
        }
      }
    }, { passive: false });

    cv.addEventListener('touchmove', function(e) {
      e.preventDefault();
      for (var i = 0; i < e.changedTouches.length; i++) {
        var t = e.changedTouches[i];

        if (t.identifier === self._joystickTouchId) {
          // 摇杆拖动
          var dx = t.clientX - self.joystick.baseX;
          var dy = t.clientY - self.joystick.baseY;
          var dist = Math.sqrt(dx * dx + dy * dy);
          var maxR = 65;
          if (dist > maxR) {
            dx = dx / dist * maxR;
            dy = dy / dist * maxR;
            dist = maxR;
          }
          self.joystick.nubX = self.joystick.baseX + dx;
          self.joystick.nubY = self.joystick.baseY + dy;
          self.joystick.dirX = dist > 8 ? dx / maxR : 0;
          self.joystick.dirY = dist > 8 ? dy / maxR : 0;
        }
      }
    }, { passive: false });

    cv.addEventListener('touchend', function(e) {
      for (var i = 0; i < e.changedTouches.length; i++) {
        var t = e.changedTouches[i];

        if (t.identifier === self._joystickTouchId) {
          self._joystickTouchId = null;
          self.joystick.active = false;
          self.joystick.dirX = 0;
          self.joystick.dirY = 0;
        }
        if (t.identifier === self._boostTouchId) {
          self._boostTouchId = null;
          self.boostBtnActive = false;
          self.boosting = false;
        }
      }
    });

    cv.addEventListener('touchcancel', function(e) {
      self._joystickTouchId = null;
      self._boostTouchId = null;
      self.joystick.active = false;
      self.joystick.dirX = 0;
      self.joystick.dirY = 0;
      self.boostBtnActive = false;
      self.boosting = false;
    });
  }

  // ==================== 网络 ====================

  async _joinGame() {
    var name = this.usernameInput.value.trim();
    if (!name) { this.usernameInput.focus(); return; }

    // 每次点击都重新计算模式配置（读取当前选中的模式和选项）
    this._readModeFromUI();

    // ===== 创建房间：两步流程 =====
    if (this.roomType === 'create') {
      // 第一步：还没创建 → POST 创建房间，显示房间码
      if (!this._roomCreated) {
        try {
          console.log('[Game] Creating room, mode:', this.gameMode, 'config:', this.modeConfig);
          var resp = await fetch('/api/rooms?mode=' + this.gameMode + '&config=' + this.modeConfig, { method: 'POST' });
          if (!resp.ok) {
            var err = await resp.json();
            this._showNotification('创建房间失败: ' + (err.detail || '请重试'));
            return;
          }
          var data = await resp.json();
          this.roomCode = data.code;
          this._roomCreated = true;
          console.log('[Game] Room created:', this.roomCode, 'mode:', data.mode);
          this._showRoomCodeInPanel();
          this._showNotification('房间 ' + this.roomCode + ' 创建成功！选择模式后点「进入游戏」');
          return;  // 等用户确认后再连接
        } catch (err) {
          console.error('[Game] Create room error:', err);
          this._showNotification('创建房间失败，请确认服务器已启动');
          return;
        }
      }
      // 第二步：已创建 → 用当前模式连接
      console.log('[Game] Entering room:', this.roomCode, 'mode:', this.gameMode, 'config:', this.modeConfig);
    }

    // ===== 加入房间 =====
    if (this.roomType === 'join') {
      var input = document.getElementById('roomCodeInput');
      this.roomCode = (input ? input.value.trim().toUpperCase() : '');
      if (!this.roomCode || this.roomCode.length < 4) {
        this._showNotification('请输入有效的房间码（4-6位）');
        if (input) input.focus();
        return;
      }
    }
    // quick match: roomCode 为 null，连 /ws

    console.log('[Game] Connecting, roomCode:', this.roomCode, 'mode:', this.gameMode, 'config:', this.modeConfig);
    this._connect(name);
    this._startLoop();
  }

  /** 从 UI 读取当前选中的模式和配置 */
  _readModeFromUI() {
    // 读取模式选项卡
    var activeModeTab = document.querySelector('.mode-tab.active');
    if (activeModeTab && activeModeTab.dataset.mode) {
      this.gameMode = activeModeTab.dataset.mode;
    }

    // 读取模式配置
    if (this.gameMode === 'timed') {
      var ts = document.getElementById('timedSelect');
      this.modeConfig = ts ? parseInt(ts.value) : 180;
    } else if (this.gameMode === 'score') {
      var ss = document.getElementById('scoreSelect');
      this.modeConfig = ss ? parseInt(ss.value) : 2000;
    } else {
      this.modeConfig = 0;
    }
    console.log('[Game] Mode from UI:', this.gameMode, 'config:', this.modeConfig);
  }

  _showRoomCodeInPanel() {
    var display = document.getElementById('roomCodeDisplay');
    var value = document.getElementById('roomCodeValue');
    if (display && value) {
      value.textContent = this.roomCode;
      display.style.display = 'flex';
    }
    // 更新按钮文字
    var btn = document.getElementById('joinBtn');
    if (btn) btn.textContent = '进 入 游 戏';
  }

  _connect(name) {
    var wsUrl;
    if (this.roomCode) {
      wsUrl = 'ws://' + window.location.host + '/ws/' + this.roomCode;
    } else {
      wsUrl = 'ws://' + window.location.host + '/ws';
    }
    console.log('[Game] Connecting to', wsUrl);

    try {
      this.ws = new WebSocket(wsUrl);
    } catch (err) {
      console.error('[Game] WebSocket creation failed:', err);
      this._showNotification('连接创建失败: ' + err.message);
      return;
    }

    this.ws.onopen = () => {
      console.log('[Game] WebSocket connected!');
      this.connected = true;
      // 快速匹配需要传模式让服务器匹配，加入房间不需要（房主已设定）
      var joinMsg = { type: 'join', username: name };
      if (this.roomType === 'quick') {
        joinMsg.mode = this.gameMode;
        joinMsg.mode_config = this.modeConfig;
      }
      console.log('[Game] Sending join:', joinMsg);
      this.ws.send(JSON.stringify(joinMsg));
    };

    this.ws.onmessage = (event) => {
      try {
        var msg = JSON.parse(event.data);
        this._handleMessage(msg);
      } catch (err) {
        console.error('[Game] Parse error:', err);
      }
    };

    this.ws.onclose = (event) => {
      console.log('[Game] WebSocket closed. Code:', event.code, 'Reason:', event.reason);
      this.connected = false;
      if (this.snakeId) {
        this._showNotification('连接断开，刷新页面重试');
      }
    };

    this.ws.onerror = (err) => {
      console.error('[Game] WebSocket error:', err);
      this._showNotification('连接失败，请确认服务器已启动');
    };
  }

  _handleMessage(msg) {
    switch (msg.type) {
      case 'error':
        console.error('[Game] Server error:', msg.msg);
        this._showNotification('错误: ' + msg.msg);
        this.connected = false;
        break;

      case 'game_init':
        console.log('[Game] Received game_init, snake_id:', msg.snake_id, 'room:', msg.room_code, 'mode:', msg.mode);
        this.snakeId = msg.snake_id;
        this.playerSnake = msg.snake;
        this.dead = false;
        if (msg.room_code) this.roomCode = msg.room_code;
        // 使用服务器返回的模式（加入者不能改模式）
        if (msg.mode) this.gameMode = msg.mode;
        // 立即显示倒计时/模式信息
        if (msg.mode_info) {
          this._updateModeInfo(msg.mode_info);
        }

        this.joinPanel.style.display = 'none';
        this.hud.style.display = 'block';
        this.deathPanel.style.display = 'none';
        var gameOverEl = document.getElementById('gameOverPanel');
        if (gameOverEl) gameOverEl.style.display = 'none';
        document.body.classList.add('playing');

        // 更新 HUD 房间码
        this._updateRoomHUD();

        // 手机端请求全屏（有助于横屏）
        if (this._isTouchDevice) {
          this._requestFullscreen();
        }

        console.log('[Game] Joined! Snake at:', msg.snake.x, msg.snake.y, 'room:', this.roomCode);
        break;

      case 'game_over':
        console.log('[Game] Game over! Winner:', msg.winner);
        document.body.classList.remove('playing');
        var dp = document.getElementById('deathPanel');
        if (dp) dp.style.display = 'none';
        var go = document.getElementById('gameOverPanel');
        if (go) go.style.display = 'flex';
        var modeName = msg.mode === 'timed' ? '限时模式' : msg.mode === 'score' ? '得分模式' : '无尽模式';
        var html = '<p>胜利者: <b style="color:#ffcc44;">' + (msg.winner || '无') + '</b></p>';
        html += '<p>分数: ' + (msg.winner_score || 0) + ' | 长度: ' + (msg.winner_length || 0) + '</p>';
        if (msg.leaderboard && msg.leaderboard.length) {
          html += '<div class="end-lb"><h3>' + modeName + ' 排行榜</h3>';
          msg.leaderboard.forEach(function(e, i) {
            var m = i === 0 ? '1st' : i === 1 ? '2nd' : i === 2 ? '3rd' : (i + 1) + 'th';
            html += '<div class="end-lb-row"><span>' + m + '</span> ' + e.username + ' <b>' + e.score + '</b></div>';
          });
          html += '</div>';
        }
        var statsEl = document.getElementById('gameOverStats');
        if (statsEl) statsEl.innerHTML = html;
        this.dead = true;
        break;

      case 'game_state':
        this.prevState = this.currentState;
        this.prevStateTime = this.stateTime;
        this.currentState = msg;
        this.stateTime = performance.now();
        if (!this.prevState) {
          this.prevState = msg;
          this.prevStateTime = this.stateTime;
        }
        if (msg.player) {
          this.playerSnake = msg.player;
          this.dead = false;
          var dp2 = document.getElementById('deathPanel');
          if (dp2) dp2.style.display = 'none';
        }
        if (msg.dead && !this.dead) {
          this.dead = true;
          this._showDeath(msg);
        }
        if (msg.mode_info) {
          this._updateModeInfo(msg.mode_info);
        }
        break;

      case 'leaderboard':
        this.lastLeaderboard = msg.scores;
        this._updateLeaderboard(msg.scores);
        break;

      case 'player_joined':
        this._showNotification(msg.username + ' 加入了游戏');
        break;

      case 'player_left':
        this._showNotification(msg.username + ' 离开了游戏');
        break;

      default:
        console.log('[Game] Unknown message type:', msg.type);
    }
  }

  // ==================== 游戏循环 ====================

  _startLoop() {
    console.log('[Game] Starting game loop');
    var loop = () => {
      this._sendInput();
      this._render();
      this.animFrameId = requestAnimationFrame(loop);
    };

    if (this._inputTimer) clearInterval(this._inputTimer);
    this._inputTimer = setInterval(() => this._sendInput(), 1000 / 30);

    this.animFrameId = requestAnimationFrame(loop);
  }

  _sendInput() {
    if (!this.connected || !this.snakeId || this.dead) return;
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    var targetX, targetY;

    if (this.joystick.active) {
      // 虚拟摇杆模式（手机）
      var jhead = this.playerSnake && this.playerSnake.segments ? this.playerSnake.segments[0] : null;
      var jhx = jhead ? jhead.x : 2000;
      var jhy = jhead ? jhead.y : 2000;
      targetX = jhx + this.joystick.dirX * 200;
      targetY = jhy + this.joystick.dirY * 200;
    } else if (this.useWASD) {
      var dx = (this._keys.d ? 1 : 0) - (this._keys.a ? 1 : 0);
      var dy = (this._keys.s ? 1 : 0) - (this._keys.w ? 1 : 0);
      if (dx !== 0 || dy !== 0) {
        var len = Math.sqrt(dx * dx + dy * dy);
        dx /= len; dy /= len;
        var head = this.playerSnake && this.playerSnake.segments ? this.playerSnake.segments[0] : null;
        var hx = head ? head.x : 2000;
        var hy = head ? head.y : 2000;
        targetX = hx + dx * 200;
        targetY = hy + dy * 200;
      } else {
        var h2 = this.playerSnake && this.playerSnake.segments ? this.playerSnake.segments[0] : null;
        targetX = h2 ? h2.x + Math.cos(this.playerSnake.angle || 0) * 200 : 2200;
        targetY = h2 ? h2.y + Math.sin(this.playerSnake.angle || 0) * 200 : 2000;
      }
    } else {
      var worldPos = this.renderer.screenToWorld(this.mouseX, this.mouseY);
      targetX = worldPos.x;
      targetY = worldPos.y;
    }

    try {
      this.ws.send(JSON.stringify({
        type: 'input',
        target_x: targetX,
        target_y: targetY,
        boost: this.boosting,
        sensitivity: this.sensitivity,
      }));
    } catch (err) {
      console.error('[Game] Send error:', err);
    }
  }

  _render() {
    if (!this.currentState) {
      var ctx = this.canvas.getContext('2d');
      ctx.fillStyle = '#1a1a2e';
      ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
      ctx.fillStyle = '#fff';
      ctx.font = '20px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('连接中...', this.canvas.width / 2, this.canvas.height / 2);
      return;
    }

    try {
      var now = performance.now();
      var elapsed = now - this.stateTime;
      var interval = Math.max(16, this.stateTime - this.prevStateTime);
      var t = Math.min(1, elapsed / interval);

      var state = this._interpolateState(this.prevState, this.currentState, t);
      this.renderState = state;

      if (this.playerSnake && this.playerSnake.segments && this.playerSnake.segments.length > 0) {
        var head = this.playerSnake.segments[0];
        var length = this.playerSnake.length || 15;
        this.renderer.updateCamera(head.x, head.y, length);
        this.renderer.drawMiniMap(this.miniMap, state.snakes || [], head.x, head.y);
      }

      this.renderer.render(state, this.snakeId);

      // 手机端虚拟摇杆（独立 try，不影响主渲染）
      if (this._isTouchDevice) {
        try {
          this.renderer.drawMobileUI(this.joystick, this.boostBtnActive);
        } catch (e) {
          console.error('[Game] Mobile UI error:', e.message || e);
        }
      }

      if (this.playerSnake) {
        this.scoreDisplay.textContent =
          '🐍 长度: ' + Math.floor(this.playerSnake.length || 0) + ' | 分数: ' + (this.playerSnake.score || 0);
        this.boostBar.textContent = this.boosting ? '⚡ 加速中...' : '⚡';
      }
    } catch (err) {
      console.error('[Game] Render error:', err.message || err, err.stack || '');
      var ctx = this.canvas.getContext('2d');
      ctx.fillStyle = '#1a1a2e';
      ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
      ctx.fillStyle = '#f55';
      ctx.font = '14px sans-serif';
      ctx.textAlign = 'center';
      var msg = (err.message || String(err)).substring(0, 50);
      ctx.fillText('渲染错误: ' + msg, this.canvas.width / 2, this.canvas.height / 2);
      ctx.fillStyle = '#f88';
      ctx.font = '12px sans-serif';
      ctx.fillText('请按 F12 查看控制台详情', this.canvas.width / 2, this.canvas.height / 2 + 26);
    }
  }

  // ==================== 房间 UI ====================

  _updateRoomHUD() {
    var badge = document.getElementById('roomBadgeCode');
    if (badge && this.roomCode) {
      badge.textContent = this.roomCode;
    }
    var roomInfo = document.getElementById('roomInfo');
    if (roomInfo && this.roomCode) {
      roomInfo.style.display = 'flex';
    }

    // HUD 复制按钮
    var copyBtn = document.getElementById('copyRoomBtnHUD');
    if (copyBtn) {
      var self = this;
      copyBtn.onclick = function() { self._copyRoomCode(); };
    }
  }

  _copyRoomCode() {
    if (!this.roomCode) return;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(this.roomCode).then(() => {
        this._showNotification('房间码已复制: ' + this.roomCode + ' 📋 发给好友吧！');
      }).catch(() => {
        this._fallbackCopy();
      });
    } else {
      this._fallbackCopy();
    }
  }

  _fallbackCopy() {
    var ta = document.createElement('textarea');
    ta.value = this.roomCode;
    ta.style.position = 'fixed'; ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); this._showNotification('房间码已复制: ' + this.roomCode); }
    catch (e) { this._showNotification('复制失败，请手动记下房间码: ' + this.roomCode); }
    document.body.removeChild(ta);
  }

  // ==================== UI 方法 ====================

  _restart() {
    if (!this.connected || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    console.log('[Game] Restarting...');
    this.ws.send(JSON.stringify({ type: 'restart' }));
    this.dead = false;
    var dp = document.getElementById('deathPanel');
    if (dp) dp.style.display = 'none';
  }

  _showDeath(msg) {
    document.body.classList.remove('playing');
    var isTimedOrScore = (this.gameMode === 'timed' || this.gameMode === 'score');
    var hintEl = document.getElementById('respawnHint');
    var restartBtn = document.getElementById('restartBtn');
    var dp = document.getElementById('deathPanel');
    if (isTimedOrScore) {
      if (hintEl) hintEl.textContent = '3秒后自动复活...';
      if (restartBtn) restartBtn.style.display = 'none';
    } else {
      if (hintEl) hintEl.textContent = '或按 空格键 快速重开';
      if (restartBtn) restartBtn.style.display = '';
    }
    if (dp) dp.style.display = 'flex';
    var scores = this.lastLeaderboard || [];
    var rank = scores.findIndex(function(s) { return s.username === game.playerSnake?.username; }) + 1;
    this.deathStats.innerHTML =
      '最终长度: <b>' + (this.playerSnake?.length || 0) + '</b><br>' +
      '得分: <b>' + (this.playerSnake?.score || 0) + '</b><br>' +
      '排名: <b>#' + (rank || '?') + '</b>';
  }

  _updateModeInfo(info) {
    var el = document.getElementById('modeInfo');
    if (!el) return;

    if (info.waiting) {
      // 计时未开始，等待真人加入
      var modeName = info.mode === 'timed' ? '⏱️ 限时模式' : info.mode === 'score' ? '🎯 得分模式' : '';
      el.innerHTML = '<span class="timer" style="color:#88ccff;">' + modeName + ' — 等待玩家加入...</span>';
      el.style.display = 'block';
    } else if (info.mode === 'timed') {
      var tl = info.time_left || 0;
      var m = Math.floor(tl / 60), s = tl % 60;
      el.innerHTML = '<span class="timer">⏱️ ' + m + ':' + (s < 10 ? '0' : '') + s + '</span>';
      el.style.display = 'block';
    } else if (info.mode === 'score') {
      el.innerHTML = '<span class="target">🎯 目标: ' + info.target + ' 分</span> | ' +
                     '<span class="timer">⏱️ ' + Math.floor((info.time_left || 0) / 60) + ':' +
                     ((info.time_left || 0) % 60 < 10 ? '0' : '') + ((info.time_left || 0) % 60) + '</span>';
      el.style.display = 'block';
    } else {
      el.style.display = 'none';
    }
  }

  _updateLeaderboard(scores) {
    if (!scores) return;
    this.lbList.innerHTML = scores.slice(0, 10).map((s, i) => {
      var medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : (i + 1) + '.';
      var isMe = this.playerSnake && s.username === this.playerSnake.username;
      return '<div class="lb-row' + (isMe ? ' is-me' : '') + '">' +
        '<span class="lb-rank">' + medal + '</span>' +
        '<span class="lb-name" style="color:' + s.color + '">' + s.username + '</span>' +
        '<span class="lb-score">' + s.score + '</span>' +
        '</div>';
    }).join('');
  }

  // ==================== 插值平滑 ====================

  _interpolateState(prev, curr, t) {
    if (!prev || !curr || t >= 0.99) return curr;
    if (t <= 0.01) return prev;

    var snakes = (curr.snakes || []).map(function(cs) {
      var ps = (prev.snakes || []).find(function(s) { return s.id === cs.id; });
      if (!ps || !ps.segments || ps.segments.length !== cs.segments.length) return cs;
      return Object.assign({}, cs, {
        segments: cs.segments.map(function(cseg, i) {
          var pseg = ps.segments[i];
          if (!pseg) return cseg;
          return { x: pseg.x + (cseg.x - pseg.x) * t, y: pseg.y + (cseg.y - pseg.y) * t };
        }),
      });
    });

    return Object.assign({}, curr, { snakes: snakes });
  }

  _showNotification(text) {
    if (!this.notification) return;
    var el = this.notification;
    el.textContent = text;
    el.style.opacity = '1';
    el.style.transform = 'translateY(0)';
    clearTimeout(this._notifTimer);
    this._notifTimer = setTimeout(() => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(-20px)';
    }, 2500);
  }
}

// 启动（带错误捕获）
console.log('[Game] Script loaded, creating client...');
var game;
try {
  game = new GameClient();
  console.log('[Game] Client created OK');
} catch (err) {
  console.error('[Game] Init error:', err);
  document.body.innerHTML = '<div style="color:#f55;padding:40px;font:16px monospace;">' +
    '<h2>初始化失败</h2><p>' + (err.message || err) + '</p>' +
    '<p>请按 F12 打开控制台查看详细错误</p></div>';
}
