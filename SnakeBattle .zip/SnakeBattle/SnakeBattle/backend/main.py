"""FastAPI 主入口 — REST API + WebSocket（多房间支持）"""

import json
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from database import init_db
from leaderboard_storage import init_leaderboard, get_leaderboard, update_leaderboard
from room_manager import room_manager, GameRoom


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期"""
    # 启动时
    await init_db()
    await init_leaderboard()
    await room_manager.start()
    print(f"[GAME] 房间管理器已启动，等待玩家加入...")
    yield
    # 关闭时
    await room_manager.stop()


app = FastAPI(title="🐍 贪吃蛇大作战", lifespan=lifespan)

# 静态文件
app.mount("/static", StaticFiles(directory="static"), name="static")


# ==================== 页面 ====================

@app.get("/", response_class=HTMLResponse)
async def index():
    """游戏主页"""
    with open("static/index.html", encoding="utf-8") as f:
        return f.read()


# ==================== 房间 API ====================

@app.post("/api/rooms")
async def create_room(mode: str = "endless", config: int = 0):
    """创建新房间"""
    try:
        room = room_manager.create_room(mode=mode, mode_config=config)
        return {
            "code": room.code,
            "mode": room.game_mode,
            "mode_config": room.mode_config,
            "msg": f"房间 {room.code} 创建成功",
        }
    except RuntimeError as e:
        raise HTTPException(status_code=429, detail=str(e))


@app.get("/api/rooms")
async def list_rooms():
    """列出所有活跃房间"""
    rooms = room_manager.list_rooms()
    return {"count": len(rooms), "rooms": rooms}


@app.get("/api/rooms/{code}")
async def get_room(code: str):
    """查询房间信息"""
    room = room_manager.get_room(code)
    if room is None:
        raise HTTPException(status_code=404, detail=f"房间 {code} 不存在")
    return room.to_dict()


@app.get("/api/rooms/{code}/world")
async def get_room_world(code: str):
    """获取房间世界概览"""
    room = room_manager.get_room(code)
    if room is None:
        raise HTTPException(status_code=404, detail=f"房间 {code} 不存在")

    eng = room.engine
    snakes = []
    for s in eng.snakes.values():
        if s.alive:
            snakes.append({
                "username": s.username,
                "x": round(s.x),
                "y": round(s.y),
                "length": int(s.length),
            })
    return {
        "room": code,
        "world": {"width": 4000, "height": 4000},
        "total_snakes": len(snakes),
        "snakes": snakes,
    }


@app.post("/api/rooms/{code}/add_ai")
async def add_ai_to_room(code: str, count: int = 2):
    """给指定房间动态添加 AI"""
    room = room_manager.get_room(code)
    if room is None:
        raise HTTPException(status_code=404, detail=f"房间 {code} 不存在")

    eng = room.engine
    added = []
    for i in range(count):
        ai_id = f"ai_dynamic_{eng.tick}_{i}_{code}"
        s = eng.add_player(ai_id, "", is_ai=True)
        added.append(s.username)
    return {"room": code, "added": len(added), "names": added}


# ==================== 全局查询 API ====================

@app.get("/api/stats")
async def get_stats(room: str = ""):
    """获取服务器状态（可指定房间）"""
    if room:
        r = room_manager.get_room(room)
        if r is None:
            raise HTTPException(status_code=404, detail=f"房间 {room} 不存在")
        eng = r.engine
        alive = sum(1 for s in eng.snakes.values() if s.alive)
        human = sum(1 for s in eng.snakes.values() if not s.is_ai)
        ai = sum(1 for s in eng.snakes.values() if s.is_ai)
        return {
            "room": room,
            "players": human,
            "ai": ai,
            "alive": alive,
            "food_count": len(eng.food_manager.foods),
            "tick": eng.tick,
            "uptime": eng.tick / 20,
        }

    # 聚合所有房间
    total_players = sum(r.human_count for r in room_manager.rooms.values())
    total_ai = sum(
        sum(1 for s in r.engine.snakes.values() if s.is_ai)
        for r in room_manager.rooms.values()
    )
    total_alive = sum(
        sum(1 for s in r.engine.snakes.values() if s.alive)
        for r in room_manager.rooms.values()
    )
    total_food = sum(
        len(r.engine.food_manager.foods)
        for r in room_manager.rooms.values()
    )
    return {
        "rooms": len(room_manager.rooms),
        "players": total_players,
        "ai": total_ai,
        "alive": total_alive,
        "food_count": total_food,
    }


@app.get("/api/leaderboard")
async def get_server_leaderboard(mode: str = "endless", limit: int = 10):
    """获取全局排行榜（数据库持久化）"""
    lb = await get_leaderboard(mode)
    return lb[:limit]


@app.get("/api/player/{username}")
async def get_player(username: str):
    """查询玩家状态（搜索所有房间）"""
    for room in room_manager.rooms.values():
        for s in room.engine.snakes.values():
            if s.username == username:
                return {
                    "username": s.username,
                    "room": room.code,
                    "alive": s.alive,
                    "score": s.score,
                    "length": int(s.length),
                    "kills": s.kills,
                    "x": round(s.x, 1),
                    "y": round(s.y, 1),
                    "is_ai": s.is_ai,
                }
    return {"error": f"未找到玩家: {username}"}


# ==================== WebSocket ====================

@app.websocket("/ws/{room_code}")
async def websocket_room(ws: WebSocket, room_code: str):
    """WebSocket 连接 — 指定房间"""
    await ws.accept()
    room_code = room_code.upper()

    room = room_manager.get_room(room_code)
    if room is None:
        await ws.send_json({"type": "error", "msg": f"房间 {room_code} 不存在"})
        await ws.close()
        return

    await _handle_ws(ws, room)


@app.websocket("/ws")
async def websocket_quick(ws: WebSocket):
    """WebSocket 连接 — 快速匹配"""
    await ws.accept()
    print(f"[WS] 快速匹配连接已接受")

    try:
        # 收到第一个 join 消息后才创建/分配房间
        data = await ws.receive_text()
        msg = json.loads(data)
        msg_type = msg.get("type", "")

        if msg_type != "join":
            await ws.send_json({"type": "error", "msg": "请先发送 join 消息"})
            await ws.close()
            return

        mode = msg.get("mode", "endless")
        mode_config = msg.get("mode_config", 0)

        # 快速匹配：找同模式房间或创建新房间
        room = room_manager.find_or_create_room(mode, mode_config)

        # 重新处理 join 消息
        await _handle_ws(ws, room, initial_msg=msg)

    except WebSocketDisconnect:
        print(f"[WS] 快速匹配连接在加入前断开")
    except Exception as e:
        print(f"[WS] 快速匹配错误: {type(e).__name__}: {e}")


async def _handle_ws(ws: WebSocket, room: GameRoom, initial_msg: dict = None):
    """处理 WebSocket 游戏连接（核心逻辑）

    重要：房间模式由房主创建时确定，加入者不可更改。
    """
    eng = room.engine
    snake_id = str(uuid.uuid4())
    username = f"玩家{snake_id[:4]}"
    snake = None

    def _build_mode_info():
        """构造当前模式信息（用于 game_init 和 game_state）"""
        info = {"mode": eng.game_mode}
        if not eng._mode_timer_started:
            info["waiting"] = True  # 等待玩家加入
        elif eng.game_mode == "timed":
            info["time_left"] = max(0, int(eng.mode_end_time - time.time()))
            info["time_total"] = eng.mode_config
        elif eng.game_mode == "score":
            info["target"] = eng.mode_config
            info["time_left"] = max(0, int(eng.mode_end_time - time.time()))
        return info

    def _make_game_init():
        """构造 game_init 消息"""
        return {
            "type": "game_init",
            "snake_id": snake_id,
            "snake": snake.to_dict() if snake else None,
            "world": {"w": 4000, "h": 4000},
            "room_code": room.code,
            "mode": eng.game_mode,
            "mode_info": _build_mode_info(),
        }

    try:
        # 处理加入（两种路径的统一入口）
        if initial_msg:
            # /ws 快速匹配：加入已有房间或新创建的房间
            username = initial_msg.get("username", username)
            # 注意：不覆盖房间模式，使用房间当前模式
            snake = eng.add_player(snake_id, username, is_ai=False)
            eng.connections[snake_id] = ws
            room.human_count += 1
            room.last_activity = time.time()

            await ws.send_json(_make_game_init())

            for sid, c in list(eng.connections.items()):
                if sid != snake_id:
                    try:
                        await c.send_json({
                            "type": "player_joined",
                            "username": username,
                        })
                    except Exception:
                        pass

        # 主消息循环
        while True:
            data = await ws.receive_text()
            msg = json.loads(data)
            msg_type = msg.get("type", "")

            if msg_type == "join":
                # /ws/{room_code} 路径：加入指定房间
                if snake is None:
                    username = msg.get("username", username)
                    # 使用房间已设定的模式，忽略客户端传来的模式
                    snake = eng.add_player(snake_id, username, is_ai=False)
                    eng.connections[snake_id] = ws
                    room.human_count += 1
                    room.last_activity = time.time()

                    await ws.send_json(_make_game_init())

                    for sid, c in list(eng.connections.items()):
                        if sid != snake_id:
                            try:
                                await c.send_json({
                                    "type": "player_joined",
                                    "username": username,
                                })
                            except Exception:
                                pass

            elif msg_type == "input":
                target_x = msg.get("target_x", 0)
                target_y = msg.get("target_y", 0)
                boost = msg.get("boost", False)
                sensitivity = msg.get("sensitivity", 1.0)
                eng.handle_input(snake_id, target_x, target_y, boost, sensitivity)

            elif msg_type == "restart":
                eng.handle_restart(snake_id)
                if snake_id in eng.connections:
                    eng.connections[snake_id] = ws
                if snake:
                    await ws.send_json({
                        "type": "game_init",
                        "snake_id": snake_id,
                        "snake": snake.to_dict(),
                        "world": {"w": 4000, "h": 4000},
                        "room_code": room.code,
                    })

            elif msg_type == "spectate":
                pass

    except WebSocketDisconnect:
        print(f"[WS] {username} 断开连接（房间 {room.code}）")
    except Exception as e:
        print(f"[WS] {username} 错误（房间 {room.code}）: {type(e).__name__}: {e}")
    finally:
        # 清理
        if snake:
            eng.remove_player(snake_id)
            room.human_count = max(0, room.human_count - 1)
            room.last_activity = time.time()
        else:
            eng.connections.pop(snake_id, None)

        # 广播玩家离开
        for sid, c in list(eng.connections.items()):
            try:
                await c.send_json({
                    "type": "player_left",
                    "username": username,
                })
            except Exception:
                pass
