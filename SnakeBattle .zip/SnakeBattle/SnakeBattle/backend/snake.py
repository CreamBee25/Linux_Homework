"""蛇实体"""

import math
import random
from dataclasses import dataclass, field

from config import (
    SNAKE_BASE_SPEED, SNAKE_BOOST_SPEED, SNAKE_SEGMENT_RADIUS,
    SNAKE_START_LENGTH, SNAKE_TURN_SPEED, SNAKE_TURN_SPEED_MIN,
    SNAKE_SEGMENT_SPACING, SNAKE_BOOST_COST, SNAKE_MIN_LENGTH,
    SNAKE_MAX_GROWTH_PER_TICK, WORLD_WIDTH, WORLD_HEIGHT,
    SNAKE_SELF_COLLISION_DELAY,
)


@dataclass
class Snake:
    """蛇实体"""
    id: str
    username: str
    color: str
    is_ai: bool = False

    # 位置和移动
    x: float = 0.0
    y: float = 0.0
    angle: float = 0.0  # 朝向 (弧度)
    target_angle: float = 0.0  # 目标朝向
    speed: float = SNAKE_BASE_SPEED
    boosting: bool = False

    # 身体段
    segments: list = field(default_factory=list)  # [(x, y), ...]
    length: int = SNAKE_START_LENGTH

    # 状态
    alive: bool = True
    score: int = 0
    kills: int = 0
    death_timer: float = 0.0
    sensitivity: float = 1.0
    pending_growth: float = 0.0  # 待增长的段数（逐tick释放）

    def __post_init__(self):
        if not self.segments:
            self.x = random.uniform(200, WORLD_WIDTH - 200)
            self.y = random.uniform(200, WORLD_HEIGHT - 200)
            self.angle = random.uniform(0, math.pi * 2)
            self.target_angle = self.angle
            self._init_segments()

    def _init_segments(self):
        """初始化身体段"""
        self.segments = []
        cx, cy = self.x, self.y
        angle_back = self.angle + math.pi  # 反方向
        for i in range(self.length):
            dist = i * SNAKE_SEGMENT_SPACING
            sx = cx + math.cos(angle_back) * dist
            sy = cy + math.sin(angle_back) * dist
            self.segments.append((sx, sy))

    @property
    def head(self) -> tuple:
        """蛇头位置"""
        return (self.x, self.y)

    @property
    def radius(self) -> float:
        """蛇头碰撞半径 — 与渲染尺寸匹配"""
        return 5.0 + min(self.length * 0.38, 28)  # 匹配前端 bodyR

    def set_target(self, target_x: float, target_y: float):
        """设置目标朝向（指向目标点）"""
        dx = target_x - self.x
        dy = target_y - self.y
        if abs(dx) > 0.1 or abs(dy) > 0.1:
            self.target_angle = math.atan2(dy, dx)

    def update(self):
        """每 tick 更新"""
        if not self.alive:
            self.death_timer -= 1.0 / 20  # 假设 20 tick/s
            return

        # 自适应转向：角度差越大转得越快，长蛇稍慢保持优雅
        angle_diff = self.target_angle - self.angle
        while angle_diff > math.pi:
            angle_diff -= math.pi * 2
        while angle_diff < -math.pi:
            angle_diff += math.pi * 2

        # 转向速度 = 基础灵敏度 × 角度差比例（小角度精细，大角度快速）
        abs_diff = abs(angle_diff)
        speed_factor = min(1.0, abs_diff / 1.2)  # 0 → 1，角度越大越接近上限
        agility = 1.0 - min(0.5, self.length * 0.002)  # 长蛇降低敏捷性，最多减50%
        max_turn = (SNAKE_TURN_SPEED_MIN +
                    (SNAKE_TURN_SPEED - SNAKE_TURN_SPEED_MIN) * speed_factor) * agility * self.sensitivity

        turn = max(-max_turn, min(max_turn, angle_diff))
        self.angle += turn
        while self.angle > math.pi:
            self.angle -= math.pi * 2
        while self.angle < -math.pi:
            self.angle += math.pi * 2

        # 速度
        self.speed = SNAKE_BOOST_SPEED if self.boosting else SNAKE_BASE_SPEED

        # 加速消耗身体（越大的蛇消耗越多）
        if self.boosting and self.length > SNAKE_MIN_LENGTH:
            boost_cost = SNAKE_BOOST_COST + self.length * 0.015
            self.length -= boost_cost
            while len(self.segments) > max(SNAKE_MIN_LENGTH, int(self.length)):
                self.segments.pop()

        # 逐tick释放待增长段数（每tick最多增长MAX_GROWTH_PER_TICK）
        if self.pending_growth > 0:
            grow_now = min(self.pending_growth, SNAKE_MAX_GROWTH_PER_TICK)
            self.length += grow_now
            self.pending_growth -= grow_now

        # 移动蛇头
        self.x += math.cos(self.angle) * self.speed
        self.y += math.sin(self.angle) * self.speed

        # 插入新头部
        self.segments.insert(0, (self.x, self.y))

        # 保持段数（多了删尾部，少了不补——等生长自然增加）
        target_len = max(SNAKE_MIN_LENGTH, int(self.length))
        while len(self.segments) > target_len:
            self.segments.pop()

    def grow(self, amount: float = 1.0):
        """增长 — 小蛇长得快，大蛇长得慢（收益递减）"""
        # 体型系数：身体越粗增长越少
        # 长度10→3x, 长度30→1.7x, 长度60→1.3x, 长度100→1.2x
        scale = 1.0 + 20.0 / max(self.length, 8.0)
        actual = amount * scale
        self.pending_growth += actual
        self.score += int(actual * 10)

    def check_boundary(self) -> bool:
        """检查是否超出边界，返回 True 表示死亡"""
        margin = SNAKE_SEGMENT_RADIUS
        return (
            self.x < margin
            or self.x > WORLD_WIDTH - margin
            or self.y < margin
            or self.y > WORLD_HEIGHT - margin
        )

    def die(self):
        """蛇死亡"""
        self.alive = False
        self.death_timer = 3.0  # 3秒后可复活

    def can_respawn(self) -> bool:
        """是否可以复活"""
        return not self.alive and self.death_timer <= 0

    def respawn(self, cap_length: int = 9999):
        """复活（重置状态，长度不超过cap_length）"""
        self.x = random.uniform(200, WORLD_WIDTH - 200)
        self.y = random.uniform(200, WORLD_HEIGHT - 200)
        self.angle = random.uniform(0, math.pi * 2)
        self.target_angle = self.angle
        self.speed = SNAKE_BASE_SPEED
        self.boosting = False
        self.length = min(SNAKE_START_LENGTH, cap_length)
        self.alive = True
        self.score = 50  # 初始分数50
        self.kills = 0
        self.death_timer = 0
        self.pending_growth = 0
        self._init_segments()

    def to_dict(self) -> dict:
        """转为传输格式"""
        return {
            "id": self.id,
            "username": self.username,
            "color": self.color,
            "segments": [{"x": s[0], "y": s[1]} for s in self.segments],
            "length": int(self.length),
            "boost": self.boosting,
            "alive": self.alive,
            "score": self.score,
            "angle": self.angle,
        }
