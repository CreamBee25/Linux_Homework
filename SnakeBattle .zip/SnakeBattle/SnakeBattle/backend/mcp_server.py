"""MCP 游戏管理服务 — 通过 REST API 查询游戏状态（房间感知）"""

import json
import os

import httpx
from mcp.server.fastmcp import FastMCP

GAME_API = os.getenv("GAME_API_URL", "http://127.0.0.1:8000")

mcp = FastMCP("snake-battle-admin")


def _api(path: str) -> dict:
    """调用游戏 REST API"""
    try:
        with httpx.Client(timeout=5) as client:
            resp = client.get(f"{GAME_API}{path}")
            resp.raise_for_status()
            return resp.json()
    except Exception as e:
        return {"error": str(e)}


def _api_post(path: str, json_data: dict = None) -> dict:
    """POST 调用游戏 REST API"""
    try:
        with httpx.Client(timeout=5) as client:
            resp = client.post(f"{GAME_API}{path}", json=json_data or {})
            resp.raise_for_status()
            return resp.json()
    except Exception as e:
        return {"error": str(e)}


@mcp.tool()
async def list_rooms() -> str:
    """列出所有活跃的游戏房间。

    Returns:
        房间列表，每间房包含 code, mode, players, ai, alive 等信息
    """
    data = _api("/api/rooms")
    if isinstance(data, dict) and "error" in data:
        return f"[ERR] {data['error']}"
    return json.dumps(data, ensure_ascii=False, indent=2)


@mcp.tool()
async def create_room(mode: str = "endless", config: int = 0) -> str:
    """创建新游戏房间。

    Args:
        mode: 游戏模式 (endless/timed/score)，默认 endless
        config: 模式配置（限时=秒数，得分=目标分），默认 0
    """
    data = _api_post(f"/api/rooms?mode={mode}&config={config}")
    if isinstance(data, dict) and "error" in data:
        return f"[ERR] {data['error']}"
    return f"[OK] 房间 {data.get('code', '?')} 创建成功！分享房间码给好友即可加入"


@mcp.tool()
async def get_room_info(code: str) -> str:
    """查询指定房间的详细信息。

    Args:
        code: 6位房间码
    """
    data = _api(f"/api/rooms/{code}")
    if isinstance(data, dict) and "error" in data:
        return f"[ERR] {data['error']}"
    return json.dumps(data, ensure_ascii=False, indent=2)


@mcp.tool()
async def add_ai_to_room(code: str = "", count: int = 2) -> str:
    """给房间添加 AI 人机。

    Args:
        code: 房间码（留空则添加到第一个房间）
        count: 要添加的 AI 数量，默认 2
    """
    if code:
        data = _api_post(f"/api/rooms/{code}/add_ai?count={count}")
    else:
        # 找第一个房间
        rooms = _api("/api/rooms")
        if isinstance(rooms, dict) and rooms.get("rooms"):
            code = rooms["rooms"][0]["code"]
            data = _api_post(f"/api/rooms/{code}/add_ai?count={count}")
        else:
            return "[ERR] 没有活跃房间，请先创建房间"
    if isinstance(data, dict) and "error" in data:
        return f"[ERR] {data['error']}"
    return f"[OK] 房间 {data.get('room', '?')} 已添加 {data.get('added', 0)} 个 AI"


@mcp.tool()
async def get_leaderboard(mode: str = "endless", limit: int = 10) -> str:
    """查询全局排行榜（跨房间）。

    Args:
        mode: 游戏模式 (endless/timed/score)
        limit: 返回前 N 名，默认 10
    """
    data = _api(f"/api/leaderboard?mode={mode}&limit={limit}")
    if isinstance(data, dict) and "error" in data:
        return f"[ERR] {data['error']}"
    return json.dumps(data, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_player_stats(username: str) -> str:
    """查询指定玩家当前状态（搜索所有房间）。

    Args:
        username: 玩家名称
    """
    data = _api(f"/api/player/{username}")
    if isinstance(data, dict) and "error" in data:
        return f"[ERR] {data['error']}"
    return json.dumps(data, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_server_status(room: str = "") -> str:
    """获取服务器实时状态。

    Args:
        room: 可选，指定房间码查看单独房间状态；留空查看全局
    """
    path = f"/api/stats?room={room}" if room else "/api/stats"
    data = _api(path)
    if isinstance(data, dict) and "error" in data:
        return f"[ERR] {data['error']}"
    return json.dumps(data, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_room_world(code: str) -> str:
    """获取房间世界地图概览（所有蛇的简要位置）。

    Args:
        code: 6位房间码
    """
    data = _api(f"/api/rooms/{code}/world")
    if isinstance(data, dict) and "error" in data:
        return f"[ERR] {data['error']}"
    return json.dumps(data, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    print("=" * 50)
    print("[MCP] 蛇蛇大作战管理服务（多房间）")
    print(f"[API] 游戏服务: {GAME_API}")
    print("[URL] MCP 端点: http://0.0.0.0:8001/mcp")
    print("=" * 50)
    mcp.run(transport="streamable-http", host="0.0.0.0", port=8001)
