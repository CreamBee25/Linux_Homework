# 🐍 贪吃蛇大作战

多人实时在线贪吃蛇对战游戏。PC 鼠标/WASD 操控，手机虚拟摇杆，支持房间系统联机对战。

---

## 环境要求

- **Python 3.10+**（tkinter 自带）
- 或 **Docker**（可选，生产部署用）

---

## 快速开始（3 种方式）

### 🚀 方式一：桌面启动器（管理员身份打开）

```bash
# 1. 安装依赖（仅首次）
cd snake-battle/backend
pip install -r requirements.txt

# 2. 启动
python launcher.py
```

点击「启动游戏」→ 复制链接发给好友 → 开玩。

### 🖥️ 方式二：命令行

```bash
cd snake-battle/backend
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

浏览器打开 `http://localhost:8000`

### 🐳 方式三：Docker

```bash
cd snake-battle
docker compose up -d
```

访问：
- 游戏：`http://localhost:8000`
- MCP 管理：`http://localhost:8001/mcp`

---

## 怎么玩

### 基本操作

| 平台 | 方向控制 | 加速 |
|------|---------|------|
| 🖥️ PC 鼠标 | 移动鼠标 | 按住左键 / 空格 |
| ⌨️ PC 键盘 | WASD | 空格 |
| 📱 手机 | 左半屏拖动摇杆 | 右半屏按住 ⚡ 按钮 |

### 联机流程

1. **房主**：选「🏠 创建房间」→ 选游戏模式 → 输入昵称 → 点创建 → 获得房间码
2. **好友**：选「🔗 加入房间」→ 输入房间码 → 输入昵称 → 加入
3. **快速匹配**：选「⚡ 快速匹配」→ 选模式 → 自动匹配同模式房间

### 游戏模式

| 模式 | 规则 |
|------|------|
| ♾️ 无尽模式 | 自由对战，死亡可复活 |
| ⏱️ 限时模式 | 时间结束最长蛇获胜（90s~10min） |
| 🎯 得分模式 | 先达目标分获胜（1000~10000 分） |

### 规则

- 吃彩色光点 → 身体变长，得分增加
- 碰到红色边界 → 死亡
- 撞到其他蛇 → 死亡（头对头双方都死）
- 击杀对手 → 尸体掉落食物
- 加速消耗身体长度，体型越大消耗越多

---

## 局域网联机

1. 启动服务器
2. 查看启动器显示的 IP（如 `http://10.35.0.56:8000`）
3. 同一 WiFi 下的设备打开该地址
4. 房主创建房间 → 分享房间码 → 好友加入
5. 测试发现北航图书馆的免费网络能够正常联机，但北航的其他局域网并不行，猜测有AP隔离

---

## MCP 管理工具

在 Claude Code 中配置 `~/.claude/mcp.json`：

```json
{
  "mcpServers": {
    "snake-battle": {
      "url": "http://localhost:8001/mcp",
      "transport": "streamable-http"
    }
  }
}
```

| 工具 | 功能 |
|------|------|
| `list_rooms` | 列出所有房间 |
| `create_room` | 创建新房间 |
| `get_server_status` | 服务器状态 |
| `get_leaderboard` | 排行榜 |
| `get_player_stats` | 玩家状态 |
| `add_ai_to_room` | 动态添加 AI |

---

## 配置参数

编辑 `backend/config.py`：

```python
WORLD_WIDTH = 4000       # 地图大小
FOOD_COUNT = 800         # 食物数量
AI_COUNT = 8             # AI 蛇数量
TICK_RATE = 20           # 服务器更新频率
SNAKE_BASE_SPEED = 7.0   # 基础速度
```

---

## 项目结构

详见 [TECHNICAL.md](TECHNICAL.md) 技术文档。

```
snake-battle/
├── README.md              # 使用说明（你正在读）
├── TECHNICAL.md           # 技术架构文档
├── Dockerfile
├── docker-compose.yml
├── backend/
│   ├── main.py            # FastAPI + WebSocket
│   ├── game_engine.py     # 游戏循环
│   ├── room_manager.py    # 房间管理
│   ├── snake.py           # 蛇实体
│   ├── food.py            # 食物系统
│   ├── collision.py       # 碰撞检测
│   ├── ai_bot.py          # AI 人机
│   ├── config.py          # 配置参数
│   ├── models.py          # 数据模型
│   ├── database.py        # 数据库
│   ├── mcp_server.py      # MCP 服务
│   ├── launcher.py        # 桌面启动器
│   ├── requirements.txt
│   └── static/
│       ├── index.html
│       ├── game.js
│       ├── renderer.js
│       └── style.css
└── docker/
    └── entrypoint.sh
```
