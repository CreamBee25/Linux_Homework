# 🐍 贪吃蛇大作战 — 技术架构文档

## 1. 项目概述

一款类似 slither.io 的多人在线贪吃蛇对战游戏。支持 PC（鼠标/WASD）和手机（虚拟摇杆）双端操控，提供房间系统、三种游戏模式、AI 人机对战。

---

## 2. 技术栈总览

| 层次 | 技术选型 | 说明 |
|------|---------|------|
| **后端框架** | FastAPI 0.115+ | 异步 Web 框架，REST API + WebSocket |
| **实时通信** | WebSocket | 服务端权威，20 tick/s 游戏状态广播 |
| **数据库 ORM** | SQLAlchemy 2.0 (async) | 异步 ORM，双数据库支持 |
| **数据库** | SQLite (默认) / PostgreSQL 16 | 开发用 SQLite，生产用 PostgreSQL |
| **前端渲染** | HTML5 Canvas + 原生 JS | 无框架，纯手写渲染引擎 |
| **容器化** | Docker + Docker Compose | 一键部署 FastAPI + PostgreSQL |
| **MCP 服务** | FastMCP | AI 可调用游戏管理工具 |
| **AI 系统** | 规则驱动 + 多方向评估 | 24 方向采样，权重评分决策 |
| **桌面启动器** | Python tkinter | 系统自带 GUI 库，无需额外安装 |

---

## 3. 系统架构

```
┌─────────────────────────────────────────────────┐
│                    客户端                        │
│  ┌──────────┐  ┌──────────┐  ┌───────────────┐ │
│  │ index.html│  │ game.js  │  │ renderer.js   │ │
│  │ 页面结构  │  │ 网络+输入 │  │ Canvas 渲染    │ │
│  └──────────┘  └──────────┘  └───────────────┘ │
└────────────────────┬────────────────────────────┘
                     │ WebSocket (20 tick/s)
┌────────────────────┴────────────────────────────┐
│                  服务端                           │
│  ┌──────────┐  ┌──────────────┐  ┌───────────┐ │
│  │ main.py  │  │room_manager.py│  │mcp_server │ │
│  │FastAPI   │  │ 房间生命周期  │  │ MCP 管理   │ │
│  │REST+WS   │  │ 50房间上限    │  │ 端口 8001  │ │
│  └────┬─────┘  └──────┬───────┘  └───────────┘ │
│       │               │                          │
│  ┌────┴───────────────┴──────────────────────┐  │
│  │           GameEngine (每房间独立)           │  │
│  │  ┌──────┐ ┌──────┐ ┌──────┐ ┌─────────┐  │  │
│  │  │snake │ │food  │ │collision│ │ai_bot  │  │  │
│  │  │蛇实体│ │食物  │ │碰撞检测│ │AI控制器 │  │  │
│  │  └──────┘ └──────┘ └──────┘ └─────────┘  │  │
│  └────────────────────┬───────────────────────┘  │
│                       │                           │
│  ┌────────────────────┴───────────────────────┐  │
│  │           数据持久化                         │  │
│  │  ┌──────────────┐  ┌────────────────────┐  │  │
│  │  │ SQLAlchemy   │  │ LeaderboardStorage │  │  │
│  │  │ ORM 模型     │  │ 排行榜持久化        │  │  │
│  │  └──────┬───────┘  └────────────────────┘  │  │
│  │         │                                    │  │
│  │  ┌──────┴───────┐  ┌────────────────────┐  │  │
│  │  │ SQLite 本地  │  │ PostgreSQL (Docker)│  │  │
│  │  └──────────────┘  └────────────────────┘  │  │
│  └─────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────┘
```

---

## 4. 核心模块详解

### 4.1 GameEngine — 游戏引擎 (`game_engine.py`)

权威服务端游戏循环，每 50ms（20Hz）执行一次 tick：

```
Tick 循环:
1. AI 决策更新（异步，每蛇间 yield）
2. 所有蛇位置更新
3. 碰撞检测（边界/自身/其他蛇/头对头）
4. 食物吃取判定
5. 食物自然补充 & 过期清理
6. AI/玩家重生
7. 游戏状态广播（含视野裁剪）
8. 胜利条件检查（限时/得分模式）
9. 排行榜定时广播
```

关键设计：
- **客户端预测补偿**：广播蛇位置时附带速度和方向，客户端插值平滑
- **视野裁剪**：食物只发送玩家周围 2000×1500 范围内的
- **自适应转向**：角度差越大转速越快，长蛇敏捷度递减（最长减 50%）
- **加速消耗**：boost 时消耗身体长度，体型越大消耗越多

### 4.2 RoomManager — 房间系统 (`room_manager.py`)

```
RoomManager
├── rooms: {room_code: GameRoom}
├── create_room()       → 6 位房间码，独立 GameEngine
├── join_room()         → 加入已有房间
├── find_or_create_room() → 快速匹配
├── leave_room()        → 玩家离开
├── _cleanup_loop()     → 30s 间隔清理空闲房间
└── MAX_ROOMS: 50       → 防止资源泄漏
```

- 房间码：6 位大写字母+数字（排除 0/O/1/I/L 易混淆字符），36^6 ≈ 21 亿种组合
- 空闲超时：无真人 5 分钟后自动销毁
- 模式锁定：创建时确定，加入者不可更改

### 4.3 Snake — 蛇实体 (`snake.py`)

```
Snake (dataclass)
├── 运动系统
│   ├── 平滑转向：角度差 → 转速（0.06~0.18 rad/tick）
│   ├── 自适应敏捷：长蛇减速
│   ├── 基础速度 7 px/tick，加速 12 px/tick
│   └── 灵敏度调节（0.3x ~ 3.0x）
├── 身体系统
│   ├── 段跟随：头插入 + 尾删除
│   ├── 逐 tick 释放生长（最多 3 段/tick）
│   └── 碰撞半径 = 5.0 + length × 0.38（最大 28px）
├── 状态
│   ├── alive / score / kills / death_timer
│   └── respawn()：随机位置复活
└── to_dict()：序列化传输
```

### 4.4 AI Bot — 人机系统 (`ai_bot.py`)

规则驱动的 AI，不做神经网络，保证可控性和低资源消耗：

```
决策流程:
1. 收集视野内信息（400px 范围）
   - 自己身体段（跳过前 8 段）
   - 其他蛇的头部和身体
   - 最近 40 个食物
2. 24 个方向均匀采样（每 15°）
3. 每个方向计算评分：
   ┌──────────────────┬──────────┐
   │ 因素             │ 权重     │
   ├──────────────────┼──────────┤
   │ 远离边界         │ 120.0    │
   │ 避让自己身体     │ 200.0    │
   │ 避让其他蛇       │ 100.0    │
   │ 避让大蛇         │ 40.0     │
   │ 避免头对头       │ 150.0    │
   │ 追寻食物         │ 15.0     │
   │ 保持当前方向     │ 5.0      │
   │ 随机扰动         │ 2.0      │
   └──────────────────┴──────────┘
4. 选最高分方向
5. 急转（>60°）时限制最大转角
6. Boost 策略：
   - 大蛇靠近 → 逃跑
   - 对方朝向自己 → 躲闪
   - 小蛇在攻击范围 → 追杀
   - 密集食物区 → 抢食
```

### 4.5 Collision — 碰撞检测 (`collision.py`)

```
check_collision(snake, others, world_w, world_h):
1. 边界碰撞 → 返回 "boundary"
2. 自身碰撞（跳过前 12 段，阈值自适应）→ "self"
3. 头对头碰撞 → "head_on"（双方都死）
4. 头撞其他蛇身体（跳过对方头部 3 段）→ "other"
```

碰撞半径 = 视觉半径 × 0.85，自身碰撞更宽容（× 0.6）。

### 4.6 Food — 食物系统 (`food.py`)

```
FoodManager
├── 常驻食物: 800 个（永不过期）
├── 自然补充: 8 个/秒（低于 2400 上限时）
├── 死亡掉落: 尸体 30% 转为食物球（60s 过期）
├── 视野查询: get_in_view(x, y, w, h)
└── 超量清理: 超过 2400 时淘汰临时食物
```

### 4.7 前端渲染引擎 (`renderer.js`)

Canvas 2D 渲染管线：

```
render(state):
1. 星空背景（预渲染到离屏 Canvas，缓存复用）
2. 网格线（桌面 100px 间距，手机 200px）
3. 红色边界
4. 食物（桌面：径向渐变 + 光晕；手机：纯色简化）
5. 蛇（客户端预测插值 + 身体波浪动画）
6. 粒子特效（死亡爆炸）
7. 手机 UI（虚拟摇杆 + 加速按钮）

相机系统:
- 平滑跟随（lerp 0.12）
- 自动缩放（蛇越长镜头越远）
- 小地图（160×160，实时位置）
```

**客户端预测**：记录每条蛇的上次位置和速度，渲染时向前推算 0~100ms，消除网络抖动。

**低性能模式**（手机自动启用）：食物无渐变、蛇身无描边高光、网格间距翻倍、尾部简化。

---

## 5. 数据库设计

### 5.1 ORM 模型 (`models.py`)

```sql
-- 玩家表
players (
    id          VARCHAR(36) PRIMARY KEY,  -- UUID
    username    VARCHAR(50) UNIQUE,
    password_hash VARCHAR(128),
    created_at  DATETIME,
    total_games INTEGER,
    total_score INTEGER,
    high_score  INTEGER,
    max_length  INTEGER,
    total_kills INTEGER
)

-- 游戏对局表
game_sessions (
    id              VARCHAR(36) PRIMARY KEY,
    started_at      DATETIME,
    ended_at        DATETIME,
    player_count    INTEGER,
    ai_count        INTEGER,
    duration_seconds INTEGER
)

-- 玩家战绩表
player_scores (
    id          VARCHAR(36) PRIMARY KEY,
    player_id   VARCHAR(36),    -- FK → players
    session_id  VARCHAR(36),    -- FK → game_sessions
    username    VARCHAR(50),
    score       INTEGER,
    max_length  INTEGER,
    kills       INTEGER,
    rank        INTEGER,
    snake_color VARCHAR(10),
    created_at  DATETIME
)

-- 排行榜表（每模式独立 Top 10）
leaderboard (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    mode        VARCHAR(20),    -- endless / timed / score
    username    VARCHAR(50),
    score       INTEGER,
    updated_at  DATETIME
)
```

### 5.2 双数据库策略

```
开发/演示         生产/部署
─────────        ─────────
SQLite            PostgreSQL 16
本地文件           Docker 容器
零配置             docker-compose
自动创建           持久化卷
```

通过环境变量 `USE_POSTGRES` 切换，默认使用 SQLite（`snake_battle.db`）。

### 5.3 排行榜持久化 (`leaderboard_storage.py`)

- 首次启动自动填充 10 条假数据（从 20 个预设名字随机生成）
- 游戏结束时合并玩家分数，同名取最高，取 Top 10 写入
- 前端通过 REST API `/api/leaderboard` 查询

---

## 6. 网络通信

### 6.1 REST API

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/` | 游戏主页 |
| POST | `/api/rooms?mode=&config=` | 创建房间 |
| GET | `/api/rooms` | 列出所有房间 |
| GET | `/api/rooms/{code}` | 房间详情 |
| GET | `/api/rooms/{code}/world` | 房间世界地图 |
| POST | `/api/rooms/{code}/add_ai` | 给房间加 AI |
| GET | `/api/stats?room=` | 服务器状态 |
| GET | `/api/leaderboard?mode=` | 全局排行榜 |
| GET | `/api/player/{username}` | 玩家查询 |

### 6.2 WebSocket 协议

```
客户端 → 服务端:
  {"type": "join", "username": "..."}
  {"type": "input", "target_x": ..., "target_y": ..., "boost": bool}
  {"type": "restart"}

服务端 → 客户端:
  {"type": "game_init", "snake": ..., "mode_info": ..., "room_code": ...}
  {"type": "game_state", "snakes": [...], "foods": [...], "scores": [...]}
  {"type": "leaderboard", "scores": [...]}
  {"type": "player_joined", "username": "..."}
  {"type": "player_left", "username": "..."}
  {"type": "game_over", "winner": "...", "leaderboard": [...]}
```

- 广播频率：20Hz（与 tick 同步）
- 食物视野裁剪：以玩家为中心 2000×1500 范围
- 消息格式：JSON，蛇段数组压缩为 `{x, y}` 键值对

---

## 7. MCP 管理服务

基于 FastMCP 的游戏管理工具，可通过 AI 助手调用：

```
snake-battle-admin (端口 8001)
├── list_rooms()        → 列出所有活跃房间
├── create_room()       → 创建新房间
├── get_room_info()     → 查询房间详情
├── add_ai_to_room()    → 动态添加 AI
├── get_leaderboard()   → 全局排行榜
├── get_player_stats()  → 玩家状态查询
├── get_server_status() → 服务器状态
└── get_room_world()    → 房间地图概览
```

实现方式：MCP 工具函数通过 `httpx` 调用游戏 REST API，作为 API 桥接层。

---

## 8. Docker 部署

```
docker-compose.yml
├── app (snake-battle-app)
│   ├── build: . (Dockerfile)
│   ├── ports: 8000 (游戏), 8001 (MCP)
│   ├── depends_on: db (healthy)
│   └── env: USE_POSTGRES=true, DATABASE_URL=...
├── db (snake-battle-db)
│   ├── image: postgres:16-alpine
│   ├── healthcheck: pg_isready
│   └── volume: pgdata (持久化)
└── volumes: snake_battle_pgdata
```

---

## 9. 目录结构

```
snake-battle/
├── README.md                 # 使用说明
├── TECHNICAL.md              # 本文档
├── Dockerfile                # 容器构建文件
├── docker-compose.yml        # 容器编排
├── .dockerignore
├── backend/
│   ├── main.py               # FastAPI 主入口 + WebSocket 路由
│   ├── game_engine.py        # 核心游戏循环
│   ├── room_manager.py       # 多房间管理
│   ├── snake.py              # 蛇实体（运动/增长/复活）
│   ├── food.py               # 食物系统（生成/掉落/过期）
│   ├── collision.py          # 碰撞检测
│   ├── ai_bot.py             # AI 控制器
│   ├── config.py             # 游戏配置参数
│   ├── models.py             # SQLAlchemy 数据模型
│   ├── database.py           # 数据库连接（SQLite/PostgreSQL）
│   ├── leaderboard_storage.py # 排行榜持久化
│   ├── mcp_server.py         # MCP 管理服务
│   ├── launcher.py           # 桌面启动器 GUI (tkinter)
│   ├── run_public.py         # ngrok 公网穿透脚本
│   ├── requirements.txt      # Python 依赖
│   └── static/
│       ├── index.html        # 游戏页面
│       ├── game.js           # 客户端（WebSocket/输入/状态管理）
│       ├── renderer.js       # Canvas 渲染引擎
│       └── style.css         # 样式表
└── docker/
    └── entrypoint.sh         # 容器启动脚本
```

---

## 10. 设计亮点

1. **服务端权威** — 所有游戏逻辑在服务端计算，客户端只做渲染和输入，防作弊
2. **房间隔离** — 每房间独立 GameEngine 实例，互不干扰
3. **自适应渲染** — 手机自动启用低功耗模式，减少 Canvas 绘制量 50%+
4. **客户端预测** — 服务端状态插值平滑，消除 50ms 网络抖动
5. **视野裁剪** — 食物按视野范围发送，减少 90% 无关数据传输
6. **双数据库** — 开发零配置 SQLite，生产高性能 PostgreSQL
7. **规则 AI** — 无机器学习依赖，24 方向加权评分，行为真实可调
8. **懒计时** — 房间创建不启动倒计时，真人进入才开始
