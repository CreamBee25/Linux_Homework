#!/bin/bash
set -e

# 后台启动 ollama 服务
ollama serve &
OLLAMA_PID=$!

# 等待服务就绪
echo "等待 Ollama 服务启动..."
for i in $(seq 1 30); do
    if ollama list > /dev/null 2>&1; then
        echo "Ollama 服务已就绪"
        break
    fi
    sleep 2
done

# 检查并拉取模型
MODEL="qwen3:0.6b"
if ollama list 2>/dev/null | grep -q "$MODEL"; then
    echo "模型 $MODEL 已存在，跳过拉取"
else
    echo "正在拉取模型 $MODEL ..."
    ollama pull "$MODEL"
    echo "模型 $MODEL 拉取完成"
fi

# 将 ollama 服务带回前台
wait $OLLAMA_PID
