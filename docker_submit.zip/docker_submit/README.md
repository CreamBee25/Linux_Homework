# Docker 部署 Ollama + MCP 服务

## 项目结构

```
docker/
├── Dockerfile              # Ollama 镜像（自动拉取 qwen3:0.6b）
├── entrypoint.sh           # 启动脚本
├── docker-compose.yml      # 编排 Ollama + MCP 服务
├── .dockerignore
├── README.md
└── mcp-server/             # MCP 鉴权服务（选做）
    ├── Dockerfile
    ├── server.py
    ├── mcd_client.py
    ├── requirements.txt
    └── .env
```

## 一、启动服务

```bash
cd docker
docker compose up -d
```

首次启动会自动拉取 `qwen3:0.6b` 模型（约 0.4GB），之后启动会复用已有模型。

## 二、查看状态

```bash
docker compose ps         # 查看容器状态
docker compose logs ollama  # 查看 Ollama 日志
```

## 三、Cherry Studio 配置

打开 Cherry Studio → 设置 → 添加模型：

| 配置项 | 值 |
|--------|-----|
| 提供商 | OpenAI 兼容接口 |
| API 地址 | `http://localhost:11434/v1` |
| API 密钥 | 随便填（Ollama 不需要） |
| 模型 | `qwen3:0.6b` |

或者直接填：

```
API 地址: http://localhost:11434/v1/chat/completions
模型名: qwen3:0.6b
```

## 四、MCP 服务（选做）

MCP 鉴权服务同步部署在 `http://localhost:8000/mcp`。

两个工具：
- `get_token` — 获取 token（无需鉴权）
- `mcdonalds_order` — 麦当劳点餐（需要 token）

设置 `.env` 中的 `MCD_TOKEN` 后使用。

## 五、常用命令

```bash
# 停止
docker compose down

# 停止并删除模型数据
docker compose down -v

# 进入 Ollama 容器
docker exec -it ollama-qwen bash

# 查看已安装模型
docker exec ollama-qwen ollama list

# 拉取其他模型
docker exec ollama-qwen ollama pull qwen3:1.8b
```

## 六、测试 API

```bash
# 测试聊天
curl http://localhost:11434/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3:0.6b",
    "messages": [{"role": "user", "content": "你好"}]
  }'

# 测试 MCP 服务
curl http://localhost:8000/mcp -X POST \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"t","version":"1"}},"id":1}'
```
