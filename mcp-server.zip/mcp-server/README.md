# MCP 鉴权服务 + 麦当劳点餐

## 项目简介

在自己的电脑上部署的 MCP 服务，包含两个工具：

| 工具 | 鉴权 | 功能 |
|------|------|------|
| `get_token` | 不需要 | 返回鉴权所需的 token |
| `mcdonalds_order` | 需要 token | 麦当劳点餐（查门店、查餐品、下单） |

---

## 快速开始

### 1. 启动服务

双击 `start_server.bat`，或在终端运行：

```bash
cd mcp-server
python server.py
```

看到以下输出表示启动成功：

```
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
[KEY] 本地 Token: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
```

按 `Ctrl+C` 停止服务。

### 2. 开始点餐

另开一个终端：

```bash
cd mcp-server
python test_order.py
```

---

## 点餐流程

### 第一步：输入位置

```
📍 查询附近门店
   城市 (回车=深圳):
   关键词 (回车=南山科技园):
```

回车使用默认值，也可以输入自己的位置，比如 `北京`、`望京`。

### 第二步：选门店

```
   找到 5 家门店:

   [1] 麦当劳深圳同方信息港餐厅
       📍 科技园北区朗山路11号  |  405m
       🏪 storeCode: 1420762

   [2] 麦当劳深圳禹洲广场餐厅
       ...

   选门店 (1-5, q=退出): 1
```

### 第三步：选餐品（支持多件）

```
   31 个分类, 141/141 款餐品

   [  1] 双层猪柳蛋麦满分四件套    ¥0.35  [四件套]  冰鲜萃新
   [  2] 猪柳蛋麦满分套餐          ¥0.26  [三件套]  人气产品
   [  3] 脆薯饼                   ¥0.12  [小食]
   ...

   编号=添加, s=搜索, d=完成, q=退出
```

| 操作 | 说明 |
|------|------|
| 输入编号 | 将该餐品加入购物车 |
| `s` | 按关键词搜索（搜名称、分类、标签） |
| `r` | 从购物车移除某件 |
| `d` | 选好了，进入下一步 |
| `q` | 退出 |

#### 搜索示例

```
   > s
   搜索关键词: 鸡

   🔍 搜索: [鸡]
   31 个分类, 8/141 款餐品

   [  1] 雪菜粥板烧鸡腿麦满分四件套    [四件套]
   [  2] 大脆鸡扒麦满分套餐          [三件套]
   ...
```

#### 购物车

选了多件后会显示购物车：

```
   🛒 购物车 (3 件):
      [1] 双层猪柳蛋麦满分四件套 x2
      [2] 脆薯饼 x1
      [3] 鲜萃冰咖 x1
```

同一餐品重复添加会自动合并数量。输入 `r` 可以移除：

```
   > r
   移除第几个? 2
   已移除: 脆薯饼
```

### 第四步：确认价格

```
💰 计算价格...
   💰 总价: ¥82.00
      双层猪柳蛋麦满分四件套 x2 = ¥70.00
      脆薯饼 x1 = ¥12.00

   取餐方式:
   [1] 堂食 - 店内用餐
   [2] 外带 - 店外取餐柜
```

### 第五步：下单

```
📋 确认下单? (y/n): y

   ✅ 订单已创建!
   📋 订单号: 1030264260000752024631753371
   🏪 门店: 麦当劳深圳同方信息港餐厅
   💰 金额: ¥82.00
   🚶 取餐: 堂食
   💳 支付链接: https://m.mcd.cn/mcp/scanToPay?orderId=...
```

---

## MCP 工具 API 参考

### get_token（无需鉴权）

返回本地鉴权 token。

```
参数: 无
返回: 鉴权 token 字符串
```

### mcdonalds_order（需要鉴权）

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | string | 是 | 鉴权 token，通过 get_token 获取 |
| action | string | 是 | 操作类型 |
| params_json | string | 是 | JSON 格式的参数字符串 |

**支持的 action：**

| action | 说明 | params_json 示例 |
|--------|------|------------------|
| `list_tools` | 列出麦当劳所有工具 | `{}` |
| `nearby_stores` | 查询附近门店 | `{"city":"深圳","keyword":"科技园","be_type":"1"}` |
| `meals` | 查询门店餐品 | `{"store_code":"1420762","order_type":"1","be_type":"1"}` |
| `meal_detail` | 餐品详情 | `{"meal_id":"xxx","store_code":"1420762"}` |
| `calculate_price` | 计算价格 | `{"store_code":"1420762","items":[{"productCode":"xxx","quantity":2}],"order_type":"1","be_type":"1"}` |
| `create_order` | 创建订单 | `{"store_code":"1420762","items":[...],"order_type":"1","be_type":"1","take_way_code":"eat-in"}` |
| `query_order` | 查询订单 | `{"order_id":"xxx"}` |

**be_type 说明：**

| 值 | 含义 |
|----|------|
| `1` | 到店自取 |
| `5` | 得来速（车道取餐） |

---

## 文件说明

```
mcp-server/
├── server.py          # MCP 服务主程序（两个工具 + 鉴权逻辑）
├── mcd_client.py      # 麦当劳 API 客户端
├── test_order.py      # 交互式点餐脚本
├── start_server.bat   # 一键启动（Windows）
├── .env               # 环境变量配置
└── requirements.txt   # Python 依赖
```

## 环境要求

- Python >= 3.10
- 依赖：`mcp`, `httpx`, `python-dotenv`
- 需要有效的麦当劳 MCP token（在 https://open.mcd.cn/mcp 获取，配置在 `.env` 中）
