"""
McDonald's MCP API 客户端
通过 JSON-RPC over Streamable HTTP 与麦当劳官方 MCP 服务通信
"""

import json
from typing import Any

import httpx

MCD_MCP_URL = "https://mcp.mcd.cn/mcp-servers/mcd-mcp"


class McDonaldsMCPClient:
    """麦当劳 MCP API 客户端"""

    def __init__(self, token: str):
        self.token = token
        self.session_id: str | None = None
        self.request_id = 0
        self._client = httpx.Client(timeout=30.0)

    def _next_id(self) -> int:
        self.request_id += 1
        return self.request_id

    def _headers(self) -> dict[str, str]:
        h = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.token}",
        }
        if self.session_id:
            h["Mcp-Session-Id"] = self.session_id
        return h

    def _rpc_call(self, method: str, params: dict | None = None) -> dict:
        """发送 JSON-RPC 请求到麦当劳 MCP"""
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
            "id": self._next_id(),
        }

        resp = self._client.post(MCD_MCP_URL, json=payload, headers=self._headers())

        # 提取 session ID
        sid = resp.headers.get("Mcp-Session-Id")
        if sid and not self.session_id:
            self.session_id = sid

        resp.raise_for_status()

        # 处理 SSE / streamable 响应
        body = resp.text.strip()
        if not body:
            return {}

        # 尝试解析为 JSON
        try:
            return resp.json()
        except json.JSONDecodeError:
            # 可能是 SSE 格式，尝试提取 data 行
            for line in body.split("\n"):
                line = line.strip()
                if line.startswith("data:"):
                    data = line[5:].strip()
                    if data:
                        return json.loads(data)
            return {"raw": body}

    def initialize(self) -> dict:
        """初始化 MCP 会话"""
        result = self._rpc_call("initialize", {
            "protocolVersion": "2025-06-18",
            "capabilities": {},
            "clientInfo": {
                "name": "mcd-local-proxy",
                "version": "1.0.0",
            },
        })
        # 发送 initialized 通知
        if self.session_id:
            self._rpc_call("notifications/initialized")
        return result

    def list_tools(self) -> list[dict]:
        """列出可用的麦当劳 MCP 工具"""
        result = self._rpc_call("tools/list")
        return result.get("result", {}).get("tools", [])

    def call_tool(self, tool_name: str, arguments: dict[str, Any]) -> dict:
        """调用麦当劳 MCP 工具"""
        if not self.session_id:
            self.initialize()

        result = self._rpc_call("tools/call", {
            "name": tool_name,
            "arguments": arguments,
        })
        return result.get("result", result)

    def query_nearby_stores(
        self,
        search_type: str = "2",
        city: str | None = None,
        keyword: str | None = None,
        be_type: str = "1",
    ) -> dict:
        """查询附近门店（到店场景）"""
        args: dict[str, Any] = {
            "searchType": search_type,
            "beType": be_type,
        }
        if city:
            args["city"] = city
        if keyword:
            args["keyword"] = keyword
        return self.call_tool("query-nearby-stores", args)

    def query_meals(self, store_code: str, order_type: str = "1",
                    be_code: str | None = None, be_type: str = "1") -> dict:
        """查询门店可售卖餐品"""
        args: dict[str, Any] = {
            "storeCode": store_code,
            "orderType": order_type,
            "beType": be_type,
        }
        if be_code:
            args["beCode"] = be_code
        return self.call_tool("query-meals", args)

    def query_meal_detail(self, meal_id: str, store_code: str) -> dict:
        """查询餐品详情"""
        return self.call_tool("query-meal-detail", {
            "mealId": meal_id,
            "storeCode": store_code,
        })

    def calculate_price(
        self,
        store_code: str,
        items: list[dict],
        order_type: str = "1",
        be_type: str = "1",
        be_code: str | None = None,
        coupon_codes: list[str] | None = None,
    ) -> dict:
        """计算订单价格"""
        args: dict[str, Any] = {
            "storeCode": store_code,
            "items": items,
            "orderType": order_type,
            "beType": be_type,
        }
        if be_code:
            args["beCode"] = be_code
        if coupon_codes:
            args["couponCodes"] = coupon_codes
        return self.call_tool("calculate-price", args)

    def create_order(
        self,
        store_code: str,
        items: list[dict],
        order_type: str = "1",
        be_type: str = "1",
        be_code: str | None = None,
        take_way_code: str | None = None,
        address_id: str | None = None,
        coupon_codes: list[str] | None = None,
    ) -> dict:
        """创建订单，返回支付链接"""
        args: dict[str, Any] = {
            "storeCode": store_code,
            "items": items,
            "orderType": order_type,
            "beType": be_type,
        }
        if be_code:
            args["beCode"] = be_code
        if take_way_code:
            args["takeWayCode"] = take_way_code
        if address_id:
            args["addressId"] = address_id
        if coupon_codes:
            args["couponCodes"] = coupon_codes
        return self.call_tool("create-order", args)

    def query_order(self, order_id: str) -> dict:
        """查询订单状态"""
        return self.call_tool("query-order", {"orderId": order_id})

    def delivery_query_addresses(self, be_type: int = 2) -> dict:
        """查询配送地址"""
        return self.call_tool("delivery-query-addresses", {"beType": be_type})

    def close(self):
        """关闭客户端"""
        self._client.close()
