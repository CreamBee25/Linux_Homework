"""
麦当劳 MCP 点餐工具 — 交互式命令行
用法: python test_order.py
"""
import json, sys, re, httpx

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

URL = "http://127.0.0.1:8000/mcp"
HEADERS = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
client = httpx.Client(timeout=60)


def init() -> str:
    resp = client.post(URL, json={
        "jsonrpc": "2.0", "method": "initialize",
        "params": {"protocolVersion": "2025-06-18", "capabilities": {},
                   "clientInfo": {"name": "cli", "version": "1.0"}},
        "id": 1
    }, headers=HEADERS)
    return resp.headers.get("Mcp-Session-Id", "")


def mcp_text(sid: str, tool: str, args: dict) -> str:
    resp = client.post(URL, json={
        "jsonrpc": "2.0", "method": "tools/call",
        "params": {"name": tool, "arguments": args}, "id": 1
    }, headers={**HEADERS, "Mcp-Session-Id": sid})
    for line in resp.text.split("\n"):
        if line.strip().startswith("data:"):
            d = json.loads(line.strip()[5:])
            c = d.get("result", {}).get("content", [{}])
            return c[0].get("text", "") if c else ""
    return ""


def mcd(sid: str, token: str, action: str, params: dict = None) -> str:
    return mcp_text(sid, "mcdonalds_order", {
        "token": token, "action": action,
        "params_json": json.dumps(params or {}),
    })


def parse_data(text: str) -> dict:
    parts = text.split("\n\n", 1)
    if len(parts) < 2:
        return {}
    try:
        inner = json.loads(parts[1])
        sc = inner.get("structuredContent", {})
        return sc.get("data", sc) if isinstance(sc, dict) else {}
    except json.JSONDecodeError:
        return {}


def pick(options: list, label: callable, prompt: str = "选择") -> int:
    """让用户从列表中选一个，返回索引"""
    while True:
        try:
            choice = input(f"\n{prompt} (1-{len(options)}, q=退出): ").strip()
            if choice.lower() == "q":
                return -1
            idx = int(choice) - 1
            if 0 <= idx < len(options):
                return idx
            print(f"  请输入 1-{len(options)}")
        except ValueError:
            print("  请输入有效数字")


# ============================================================
print()
print("╔" + "═" * 53 + "╗")
print("║" + "  🍔 麦当劳 MCP 点餐系统".ljust(47) + "║")
print("╚" + "═" * 53 + "╝")

sid = init()

# ── 1. 获取 Token ──
text = mcp_text(sid, "get_token", {})
token = re.search(r"Token: ([a-f0-9-]+)", text).group(1)
print(f"\n🔑 Token: {token[:20]}...")

# ── 2. 查门店 ──
print("\n" + "─" * 55)
print("📍 查询附近门店")

city = input("   城市 (回车=深圳): ").strip() or "深圳"
keyword = input("   关键词 (回车=南山科技园): ").strip() or "南山科技园"

print("\n   查询中...")
text = mcd(sid, token, "nearby_stores", {
    "city": city, "keyword": keyword, "be_type": "1",
})
if "[ERR]" in text:
    print(f"   ❌ {text}"); sys.exit(1)

data = parse_data(text)
stores = data if isinstance(data, list) else data.get("data", [])
if isinstance(stores, dict):
    stores = stores.get("data", [])

if not stores:
    print("   ❌ 未找到门店"); sys.exit(1)

print(f"\n   找到 {len(stores)} 家门店:\n")
for i, s in enumerate(stores):
    print(f"   [{i+1}] {s.get('storeName')}")
    print(f"       📍 {s.get('address')}")
    print(f"       🚶 {s.get('distance')}m  |  🏪 {s.get('storeCode')}")
    print()

idx = pick(stores, lambda s: s.get("storeName"), "选门店")
if idx < 0:
    print("已退出"); sys.exit(0)

store = stores[idx]
store_code = store["storeCode"]
print(f"\n   ✅ 已选: {store['storeName']}")

# ── 3. 加载餐品 ──
print("\n" + "─" * 55)
print("🍽️  加载餐品...")
text = mcd(sid, token, "meals", {
    "store_code": store_code, "order_type": "1", "be_type": "1",
})
if "[ERR]" in text:
    print(f"   ❌ {text}"); sys.exit(1)

data = parse_data(text)
categories = data.get("categories", [])
meals_dict = data.get("meals", {})

all_meals = []
for cat in categories:
    for item in cat.get("meals", []):
        code = item.get("code", "")
        detail = meals_dict.get(code, {})
        all_meals.append({
            "code": code,
            "name": detail.get("name", code),
            "price": detail.get("currentPrice", ""),
            "category": cat.get("name", ""),
            "tags": item.get("tags", []),
        })

# ── 3. 选餐品（支持多件）──
cart = []  # [{"code":..., "name":..., "qty":..., "price":...}, ...]
filtered = all_meals
keyword = ""

while True:
    # 显示购物车
    if cart:
        print(f"\n   🛒 购物车 ({len(cart)} 件):")
        total_qty = 0
        for i, item in enumerate(cart):
            p = f"¥{int(item['price'])/100:.2f}" if item['price'] and str(item['price']).isdigit() else ""
            print(f"      [{i+1}] {item['name'][:30]} x{item['qty']}  {p}")
            total_qty += item['qty']
        print()

    if keyword:
        kw = keyword.lower()
        filtered = [m for m in all_meals if
                    kw in m["name"].lower() or
                    kw in m["category"].lower() or
                    any(kw in t.lower() for t in m["tags"])]
        if not filtered:
            print(f"   ❌ 没有匹配 [{keyword}] 的餐品")
            keyword = ""
            filtered = all_meals
            continue

    print(f"   {len(categories)} 个分类, {len(filtered)}/{len(all_meals)} 款餐品")
    if keyword:
        print(f"   🔍 搜索: [{keyword}]")
    print()

    for i, m in enumerate(filtered[:20]):
        price = f"¥{int(m['price'])/100:.2f}" if m['price'] and str(m['price']).isdigit() else ""
        tags = " | ".join(m['tags']) if m['tags'] else ""
        print(f"   [{i+1:3d}] {m['name'][:35]:35s} {price:>8s}  [{m['category']}]  {tags}")
    if len(filtered) > 20:
        print(f"   ... 还有 {len(filtered)-20} 款，请缩小搜索范围")

    actions = ["编号=添加"]
    if cart:
        actions.append("r=移除")
    actions.append("s=搜索")
    actions.append("d=完成")
    actions.append("q=退出")
    print(f"\n   {', '.join(actions)}")
    choice = input("   > ").strip()

    if choice.lower() == "q":
        print("已退出"); sys.exit(0)
    if choice.lower() == "d":
        if not cart:
            print("   购物车是空的！")
            continue
        break
    if choice.lower() == "s":
        keyword = input("   搜索关键词: ").strip()
        continue
    if choice.lower() == "r" and cart:
        try:
            ri = int(input("   移除第几个? ").strip()) - 1
            if 0 <= ri < len(cart):
                removed = cart.pop(ri)
                print(f"   已移除: {removed['name']}")
            else:
                print(f"   请输入 1-{len(cart)}")
        except ValueError:
            print("   请输入有效编号")
        continue

    try:
        idx = int(choice) - 1
        if 0 <= idx < len(filtered):
            meal = filtered[idx]
            qty = input(f"   数量 (回车=1): ").strip()
            qty = int(qty) if qty.isdigit() else 1
            # 检查是否已在购物车
            existing = next((c for c in cart if c["code"] == meal["code"]), None)
            if existing:
                existing["qty"] += qty
                print(f"   ✅ 已加: {meal['name']} (现已 x{existing['qty']})")
            else:
                cart.append({
                    "code": meal["code"],
                    "name": meal["name"],
                    "price": meal["price"],
                    "qty": qty,
                })
                print(f"   ✅ 已加: {meal['name']} x{qty}")
        else:
            print(f"   请输入 1-{min(len(filtered),20)}")
    except ValueError:
        print("   请输入有效编号、s 或 q")

print(f"\n   🛒 最终购物车: {sum(c['qty'] for c in cart)} 件商品")

# ── 4. 计算价格 ──
print("\n" + "─" * 55)
print("💰 计算价格...")
order_items = [{"productCode": c["code"], "quantity": c["qty"]} for c in cart]
text = mcd(sid, token, "calculate_price", {
    "store_code": store_code,
    "items": order_items,
    "order_type": "1", "be_type": "1",
})
if "[ERR]" in text:
    print(f"   ❌ {text}")
else:
    data = parse_data(text)
    total = data.get("price", data.get("totalPrice", "?"))
    if total and str(total).isdigit():
        print(f"\n   💰 总价: ¥{int(total)/100:.2f}")
    product_list = data.get("productList", [])
    for p in product_list:
        print(f"      {p.get('productName')} x{p.get('quantity')} = ¥{int(p.get('subtotal',0))/100:.2f}")
    take_way_list = data.get("takeWayList", [])
    print(f"\n   取餐方式:")
    for i, tw in enumerate(take_way_list):
        print(f"   [{i+1}] {tw.get('title')} - {tw.get('subtitle')}")

    idx = pick(take_way_list, lambda tw: tw.get("title"), "选取餐方式")
    if idx < 0:
        print("已退出"); sys.exit(0)
    take_way_code = take_way_list[idx]["code"]

# ── 5. 下单 ──
print("\n" + "─" * 55)
confirm = input("📋 确认下单? (y/n): ").strip().lower()
if confirm != "y":
    print("已取消"); sys.exit(0)

print("   下单中...")
text = mcd(sid, token, "create_order", {
    "store_code": store_code,
    "items": order_items,
    "order_type": "1", "be_type": "1",
    "take_way_code": take_way_code,
})
if "[ERR]" in text:
    print(f"   ❌ {text}")
else:
    data = parse_data(text)
    order_id = data.get("orderId", "")
    pay_url = data.get("payH5Url") or data.get("payUrl", "")
    detail = data.get("orderDetail", data)

    print(f"\n   ✅ 订单已创建!")
    print(f"   📋 订单号: {order_id}")
    print(f"   🏪 门店: {detail.get('storeName', store['storeName'])}")
    print(f"   💰 金额: ¥{detail.get('totalAmount', '?')}")
    print(f"   🚶 取餐: {detail.get('takeWay', '?')}")
    print(f"   ⏰ 有效期: {detail.get('expirePayTime', '?')}")
    if pay_url:
        print(f"\n   💳 支付链接: {pay_url}")

client.close()
print("\n" + "═" * 55)
print("  🎉 完成！")
print("═" * 55)
