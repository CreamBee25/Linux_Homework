@echo off
cd /d "C:\Users\ASUS\Desktop\python\mcp-server"
echo ========================================
echo   MCP 鉴权服务启动中...
echo   地址: http://127.0.0.1:8000/mcp
echo   按 Ctrl+C 停止服务
echo ========================================
echo.
python server.py
pause
