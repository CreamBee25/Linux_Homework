"""
本地 MCP 鉴权代理服务
- get_token: 无需鉴权，返回本地 token
- mcdonalds_order: 需要本地 token 鉴权，代理到麦当劳官方 MCP API
"""

import json
import os
import uuid

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

from mcd_client import McDonaldsMCPClient

# 加载环境变量
load_dotenv()

# 本地鉴权 token（服务启动时自动生成）
LOCAL_TOKEN = str(uuid.uuid4())
# 麦当劳 MCP token（从环境变量读取）
MCD_TOKEN = os.getenv("MCD_TOKEN", "")

# 创建 MCP 服务
mcp = FastMCP("mcd-local-gateway")


def get_mcd_client() -> McDonaldsMCPClient | None:
    """获取麦当劳 MCP 客户端，如果未配置 token 则返回 None"""
    if not MCD_TOKEN:
        return None
    client = McDonaldsMCPClient(MCD_TOKEN)
    client.initialize()
    return client


# ==================== 工具2：获取 token（无需鉴权）====================


@mcp.tool()
async def get_token() -> str:
    """获取本地鉴权 token（无需鉴权）。
    返回当前服务实例的鉴权 token，用于调用 mcdonalds_order 工具。

    Returns:
        鉴权 token 字符串，同时提示是否已配置麦当劳 MCP token
    """
    mcd_status = "[OK] 已配置" if MCD_TOKEN else "[WARN] 未配置（请设置 MCD_TOKEN 环境变量）"
    return (
        f"[KEY] 本地鉴权 Token: {LOCAL_TOKEN}\n"
        f"[MCD] 麦当劳 MCP: {mcd_status}\n"
        f"\n使用方法：调用 mcdonalds_order 时传入此 token"
    )


# ==================== 工具1：麦当劳点餐（需要鉴权）====================


@mcp.tool()
async def mcdonalds_order(token: str, action: str, params_json: str) -> str:
    """麦当劳点餐服务（需要 token 鉴权）。

    支持的操作 (action):
    - list_tools:       列出麦当劳 MCP 所有可用工具
    - nearby_stores:    查询附近门店
    - meals:            查询门店餐品
    - meal_detail:      查询餐品详情
    - calculate_price:  计算价格
    - create_order:     创建订单（返回支付链接）
    - query_order:      查询订单状态
    - delivery_addresses: 查询配送地址
    - raw:              直接调用指定工具（需在 params_json 中传 tool_name 和 arguments）

    Args:
        token:       本地鉴权 token（通过 get_token 获取）
        action:      操作类型
        params_json: JSON 格式的参数字符串，各 action 所需参数见下方说明

    各 action 的 params_json 参数说明：
        nearby_stores:    {"city": "北京", "keyword": "望京", "be_type": "1"}  be_type: 1=到店自取, 5=得来速
        meals:            {"store_code": "门店编号"}
        meal_detail:      {"meal_id": "餐品ID", "store_code": "门店编号"}
        calculate_price:  {"store_code": "...", "items": [{"mealId": "...", "quantity": 1}]}
        create_order:     {"store_code": "...", "items": [...], "order_type": "1"}
        query_order:      {"order_id": "订单ID"}
        delivery_addresses: {} 或 {"be_type": 2}
        raw:              {"tool_name": "工具名", "arguments": {...}}
    """
    # ---- 鉴权 ----
    if token != LOCAL_TOKEN:
        return "[ERR] 鉴权失败：token 无效！请通过 get_token 获取正确的 token。"

    # ---- 检查麦当劳 token ----
    if not MCD_TOKEN:
        return (
            "[ERR] 麦当劳 MCP Token 未配置！\n"
            "请在 https://open.mcd.cn/mcp 注册获取 token，然后设置环境变量：\n"
            "  export MCD_TOKEN='your_token_here'\n"
            "或创建 .env 文件：MCD_TOKEN=your_token_here"
        )

    # ---- 解析参数 ----
    try:
        params = json.loads(params_json) if params_json else {}
    except json.JSONDecodeError as e:
        return f"[ERR] 参数 JSON 解析失败：{e}"

    # ---- 创建麦当劳客户端 ----
    try:
        client = McDonaldsMCPClient(MCD_TOKEN)
        client.initialize()
    except Exception as e:
        return f"[ERR] 连接麦当劳 MCP 服务失败：{e}"

    try:
        result: dict | list | str

        if action == "list_tools":
            tools = client.list_tools()
            # 格式化输出
            lines = ["[MCD] 麦当劳 MCP 可用工具：", ""]
            for t in tools:
                name = t.get("name", "?")
                desc = t.get("description", "无描述")
                lines.append(f"  • {name}")
                lines.append(f"    {desc}")
            result_str = "\n".join(lines)
            return result_str

        elif action == "nearby_stores":
            city = params.get("city")
            keyword = params.get("keyword", params.get("city", ""))
            be_type = str(params.get("be_type", "1"))
            search_type = str(params.get("search_type", "2"))
            if not city and not keyword:
                return "[ERR] 请提供城市 (city) 和/或关键词 (keyword)"
            result = client.query_nearby_stores(
                search_type=search_type, city=city, keyword=keyword, be_type=be_type
            )

        elif action == "meals":
            store_code = params.get("store_code", "")
            order_type = str(params.get("order_type", "1"))
            be_type = str(params.get("be_type", "1"))
            be_code = params.get("be_code")
            if not store_code:
                return "[ERR] 请提供 store_code（门店编号，通过 nearby_stores 获取）"
            result = client.query_meals(store_code, order_type, be_code, be_type)

        elif action == "meal_detail":
            meal_id = params.get("meal_id", "")
            store_code = params.get("store_code", "")
            if not meal_id or not store_code:
                return "[ERR] 请提供 meal_id 和 store_code"
            result = client.query_meal_detail(meal_id, store_code)

        elif action == "calculate_price":
            store_code = params.get("store_code", "")
            items = params.get("items", [])
            order_type = str(params.get("order_type", "1"))
            be_type = str(params.get("be_type", "1"))
            be_code = params.get("be_code")
            coupon_codes = params.get("coupon_codes")
            if not store_code or not items:
                return "[ERR] 请提供 store_code 和 items"
            result = client.calculate_price(store_code, items, order_type, be_type, be_code, coupon_codes)

        elif action == "create_order":
            store_code = params.get("store_code", "")
            items = params.get("items", [])
            order_type = str(params.get("order_type", "1"))
            be_type = str(params.get("be_type", "1"))
            be_code = params.get("be_code")
            take_way_code = params.get("take_way_code")
            address_id = params.get("address_id")
            coupon_codes = params.get("coupon_codes")
            if not store_code or not items:
                return "[ERR] 请提供 store_code 和 items"
            result = client.create_order(
                store_code, items, order_type, be_type, be_code,
                take_way_code, address_id, coupon_codes
            )

        elif action == "query_order":
            order_id = params.get("order_id", "")
            if not order_id:
                return "[ERR] 请提供 order_id"
            result = client.query_order(order_id)

        elif action == "delivery_addresses":
            be_type = params.get("be_type", 2)
            result = client.delivery_query_addresses(be_type)

        elif action == "raw":
            tool_name = params.get("tool_name", "")
            arguments = params.get("arguments", {})
            if not tool_name:
                return "[ERR] 请提供 tool_name"
            result = client.call_tool(tool_name, arguments)

        else:
            return (
                f"[ERR] 未知操作: {action}\n"
                f"支持的操作: list_tools, nearby_stores, meals, meal_detail, "
                f"calculate_price, create_order, query_order, delivery_addresses, raw"
            )

        # 格式化结果
        client.close()
        try:
            return (
                f"[OK] {action} 执行成功\n\n"
                f"{json.dumps(result, ensure_ascii=False, indent=2)}"
            )
        except UnicodeEncodeError:
            return (
                f"[OK] {action} 执行成功\n\n"
                f"{json.dumps(result, ensure_ascii=True, indent=2)}"
            )

    except Exception as e:
        client.close()
        return f"[ERR] 调用麦当劳 MCP 失败：{e}"


# ==================== 启动入口 ====================

if __name__ == "__main__":
    print("=" * 50)
    print("[MCP] 本地 MCP 鉴权代理服务")
    print("=" * 50)
    print(f"[KEY] 本地 Token: {LOCAL_TOKEN}")
    print(f"[MCD] 麦当劳 MCP: {'[OK] 已配置' if MCD_TOKEN else '[WARN] 未配置（请设置 MCD_TOKEN）'}")
    print(f"[URL] 服务地址: http://127.0.0.1:8000/mcp")
    print("=" * 50)
    print()

    mcp.run(transport="streamable-http")
